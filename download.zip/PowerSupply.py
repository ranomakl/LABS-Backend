version = "28th April 2026"
author  = "Matthias Schmidt"
pythonVersion = "3.10"

# modules for file handling
import os
from pathlib import Path

# modules to get information about operating system, user etc. ...
import platform # operating system
import socket # information on PC name
import getpass # information on user
import psutil # get memory and harddrive space
import sys    # get Python version

# modules to dynamically import wrappers for powerSupply
import importlib

# modules to parse xml file
import xml.etree.ElementTree as ET

# modules required for graphical user interface
import tkinter as tk
from tkinter import ttk # requiresd for notebook with tabs
from tkinter import messagebox
from tkinter import filedialog # required for saving data, logs etc.
from tkinter import scrolledtext # to display long text in separate windows with scrollbar

# numpy and matplotlib for plotting the power supply data
import matplotlib.pyplot as plt
import numpy as np

# modules required to make copies of instances
import copy

# time, e.g. for wait in voltage ramps
import time
# time stamps for logging
import datetime

# threading
import threading

# needed to log events and inspect stack
import inspect

#######################################
# logging
# set-up a logger for console output
import logging
logging.basicConfig(format='%(asctime)s [%(levelname)s] %(message)s', level=logging.DEBUG) # set level=logging.DEBUG for debugging or logging.INFO for info
logFormatter = logging.Formatter('%(asctime)s [%(threadName)-12.12s][%(levelname)-8.8s] %(message)s')
log = logging.getLogger() # this is the root logger for descendent logger for this class use log = logging.getLogger(__name__)

# set-up logger to write session log files
#   make a time stamp for files
tstart = datetime.datetime.now() # start time, can be used later, e.g. for saving data with time stamp
ts = str(tstart.year)+str(tstart.month).zfill(2)+str(tstart.day).zfill(2)+"-"+str(tstart.hour).zfill(2)+str(tstart.minute).zfill(2)+str(tstart.second).zfill(2)
#   get file handler
try:
  if os.path.isdir("./session-logs"): # if directory session-logs does exist add FileHandler to logger
    #os.mkdir("./session-logs")
    logfileHandler = logging.FileHandler(f"./session-logs/power-supply_{ts}.log", 'w')
    logfileHandler.setLevel(logging.INFO)
    log.addHandler(logfileHandler)
  else:
    log.warning("directory for session logs (session-logs) doesn't exist - should be created")
except:
  log.warning("cannot write session log file - insufficient permissions")
del ts



#######################################


# import some tools for list / float / String ...
from PowerBison.LoggedLists import IntList
from PowerBison.LoggedLists import FloatList
from PowerBison.LoggedLists import StringList
from PowerBison.LoggedLists import BoolList


###############################################################################################################################
# definition of the class PowerSupplyGui

class PowerSupply():
    """
    Class that describes the basic functionality of an abstract power supply with N channels.
    Contains
    """
    # class variable to keep references to all instances of this class
    # as there could potentially be more than one power supplies in the setup
    _instances = []

    @classmethod
    def getNumberOfInstances(cls):
      """Class method to return the number of instances of PowerSupplyGUI"""
      return len(cls._instances)

    def __del__(self):
        """Delete the instance and remove its reference from the class variable instances."""
        if self in PowerSupply._instances:
          PowerSupply._instances.remove(self)

    # deal with wrappers
    _wrapperRegistry = {} # registry for all wrappers

    @classmethod
    def registerWrapper(cls, tagName):
        """Decorator to register wrappers."""
        def decorator(wrapperClass):
            cls._wrapperRegistry[tagName] = wrapperClass
            return wrapperClass
        return decorator

    @classmethod
    def discoverWrappers(cls):
        """Will load all wrappers for powerSupply in subfolder powerSupplyWrappers."""
        wrapperDir = Path(__file__).parent / "powerSupplyWrappers"
        for moduleFile in wrapperDir.glob("PowerSupplyWrapper_*.py"):
            moduleName = moduleFile.stem
            #__package__ = "Python_PowerSupply"
            print(f"package: {__package__}")
            importlib.import_module(f".powerSupplyWrappers.{moduleName}",package=__package__)
            log.info(f"imported {moduleName}")

    def __init__(self, name="Power Supply",
                 channels=1):
        # class variables
        self.name              = name # name of power supply
        ###################################################################################
        # override this in wrapper classes with communication port with the particular power supply
        self.port           = "not connected"
        ###################################################################################


        self._description      = StringList([f"channel {i}" for i in range(channels)]) # description of what the different channels power up
        self.numberOfChannels  = channels # power supply channels
        self._Vmax             = FloatList(name="Vmax", data=[3.0]*self.numberOfChannels)  # upper limit voltage(s)
        self._Vmin             = FloatList(name="Vmin", data=[0.0]*self.numberOfChannels)  # lower limit voltage(s)
        self._Imax             = FloatList(name="Imax", data=[0.1]*self.numberOfChannels)  # upper limit current(s)
        self._Imin             = FloatList(name="Imin", data=[0.0]*self.numberOfChannels)  # lower limit current(s)
        self._Vset             = FloatList(name="Vset", data=[0.0]*self.numberOfChannels)  # set point voltage(s)
        self._Iset             = FloatList(name="Iset", data=[0.0]*self.numberOfChannels)  # set point currents(s)
        self._OutputOn         = BoolList(name="OutputOn", data=[False]*self.numberOfChannels)  # turn output on/off

        self._sessionLog       = [] # whenever a class variable changes state a this is logged here

        # use module "inspect" to check whether registerCallbacks is overridden in child (e.g. PowerSupplyPlus)
        # do not call the method here because in that case the overridden version would be called
        # and then perhaps some class variables would not be existing at this point
        if getattr(self.__class__, 'registerCallbacks', None) is getattr(PowerSupply, 'registerCallbacks', None):
            self.registerCallbacks()

        # add this instance to global list of instances of class PowerSupply
        PowerSupply._instances.append(self)
        log.debug("an instance of PowerSupply has been constructed")

    def logger(self,name=None, data=None):
        """
        This is a callback function for the class variables.
        Every time a class variable changes its state this is written to session-log.
        """
        # [0] make a time stamp
        ts = datetime.datetime.now()
        tm = str(ts.year)+str(ts.month).zfill(2)+str(ts.day).zfill(2)+"-"+str(ts.hour).zfill(2)+str(ts.minute).zfill(2)+str(ts.second).zfill(2)
        logEntry = [tm]

        # [1] leave information about the calling class-instance and the method used
        stack = inspect.stack()
        if name is None:
            caller = ":"+stack[1].function
        else:
            caller = name+":"+stack[1].function
        # add method name of the calling method
        logEntry.append(caller)

        # [2] values
        logEntry.append(copy.copy(data)) # copy is necessary as otherwise it is just the pointer to data that is saved

        # write to session log
        self._sessionLog.append(logEntry)

    @property
    def sessionLog(self):
        return self._sessionLog

    def sessionLogClear(self):
        self._sessionLog.clear()
        return

    def sessionLogWrite2File(self,path2File):
        """
        Write entire session log to text-file.
        This will overwrite the file.
        """
        with open(path2File,"w") as logfile:
            for entry in self._sessionLog:
                logfile.write(str(entry[0])+"\t"+str(entry[1])+"\t"+str(entry[2])+"\n")


    def registerCallbacks(self):
        """Register logger function to all property variables of the class (e.g. Vmax, Vmin ....) which are of type LoggedList."""
        self._Vmax.register_callback(self.logger)
        self._Vmin.register_callback(self.logger)
        self._Imax.register_callback(self.logger)
        self._Imin.register_callback(self.logger)
        self._Vset.register_callback(self.logger)
        self._Iset.register_callback(self.logger)
        self._OutputOn.register_callback(self.logger)

    @property
    def Vmax(self):
        """Upper limit output voltage. List with an entry for each channel."""
        return self._Vmax

    @Vmax.setter
    def Vmax(self, val):
        self._Vmax.set(val)

    @property
    def Vmin(self):
        """Lower limit output voltage. List with an entry for each channel."""
        return self._Vmin

    @Vmin.setter
    def Vmin(self, val):
        self._Vmin.set(val)

    @property
    def Imax(self):
        """Maximum current. List with an entry for each channel."""
        return self._Imax

    @Imax.setter
    def Imax(self, val):
        self._Imax.set(val)

    @property
    def Imin(self):
        """Minimal current. List with an entry for each channel."""
        return self._Imin

    @Imin.setter
    def Imin(self, val):
        self._Imin.set(val)

    @property
    def Vset(self):
        """
        Voltage set-point (e.g. set by user). List with an entry for each channel.
        Note: Don't use this method to set the voltage. Use setVoltage instead.
        """
        return self._Vset

    @Vset.setter
    def Vset(self, val):
        self._Vset.set(val)

    @property
    def Iset(self):
        """Current set-point (e.g. set by user). List with an entry for each channel."""
        return self._Iset

    @Iset.setter
    def Iset(self, val):
        self._Iset.set(val)

    @property
    def OutputOn(self):
        """Here the output state (on=True, off=False) for all channels is stored in a list."""
        return self._OutputOn

    @OutputOn.setter
    def OutputOn(self, onOff):
        self._OutputOn.set(onOff)

    @property
    def description(self):
        """A description of the different power supply channels."""
        return self._description

    @description.setter
    def description(self, val):
        self._description.set(val)

    def setOutputOn(self, onOff=True, channel=0):
        """
        Turn on (onOff=True) or off (onOff=False) the output of the power supply.
        Method must be overridden for the particular power-supply in derived classes.
        If the power supply does not support this you can override the function by calling setVoltage(0.0).
        Method returns on=True/False.
        """
        # send command to power-supply
        ###################################################################################
        # add code for communication with the particular power supply here
        # IMPORTANT NOTE: make sure that the over-ridden method ends with:
        # ...
        # self.OutputOn.set(new_data=onOff,index=channel)
        # return onOff
        ###################################################################################
        # log the event
        log.info("sent channel "+str(channel)+" outputOn="+str(onOff)+" to power supply")
        # update value in PowerSupply instance
        self.OutputOn.set(new_data=onOff,index=channel)
        return onOff

    def setOutputOff(self,channel=0):
        return self.setOutputOn(onOff=False, channel=channel)

    def setVoltage(self, V, channel=0, logLevel=logging.INFO):
        """
        Change voltage set-point of the power-supply.
        Method must be overridden for the particular power-supply in derived classes.
        If successful return True otherwise return False.
        """
        if V<self.Vmin[channel] or V>self.Vmax[channel]:
            log.info("cannot set voltage to "+str(V)+"V for channel "+str(channel)+" as it is out of range ("+str(self.Vmin[channel])+"V, "+str(self.Vmax[channel])+"V)")
            if V<self.Vmin[channel]: self.setVoltage(self.Vmin[channel],channel)
            else: self.setVoltage(self.Vmax[channel],channel)
        else:
            # send command to power-supply
            ###################################################################################
            # replace this line and add code for communication with the particular power supply
            ###################################################################################
            # log the event
            log.log(logLevel, f"voltage set-point of channel {channel} changed to {V}V")
            # update set-point value in PowerSupply instance
            self.Vset.set(new_data=round(V,3),index=channel)

    def getVoltage(self, channel=0):
        """
        Try to read the output voltage from the power supply.
        Method must be overridden for the particular power-supply in derived classes.
        """
        ###################################################################################
        # When overriding add code to send command to power-supply here and return value if successful or error code in case value could not be read.
        ###################################################################################
        return 1.2345678

    def setCurrent(self, I, channel=0, logLevel=logging.INFO):
        """
        Change current set-point of the power-supply.
        Method must be overridden for the particular power-supply in derived classes.
        If successful return True otherwise return False
        """
        if I<self.Imin[channel] or I>self.Imax[channel]:
            log.info(f"cannot set current to {I}A for channel {channel} as it is out of range ({self.Imin[channel]}A, {self.Imax[channel]}A)")
            # call method again with the according current limit
            if I<self.Imin[channel]: self.setCurrent(I=self.Imin[channel],channel=channel)
            else: self.setCurrent(I=self.Imax[channel],channel=channel)
        else:
            # send command to power-supply
            ###################################################################################
            # replace this line and add code for communication with the particular power supply
            ###################################################################################
            # log the event
            log.log(logLevel,"current set-point of channel {channel} changed to {I} A")
            # update set-point value in PowerSupply instance
            self.Iset.set(new_data=round(I,3),index=channel)
        return

    def getCurrent(self, channel=0):
        """
        Try to read the output current from the power supply.
        Method must be overridden for the particular power-supply in derived classes.
        """
        ###################################################################################
        # When overriding add code to send command to power-supply here and return value if successful or error code in case value could not be read.
        ###################################################################################
        return 1.2345678

    def getPower(self, channel=0):
        """
        Return the output power via getCurrent(channel)*getVoltage(channel).
        """
        return self.getCurrent(channel)*self.getVoltage(channel)

class PowerSupplyPlus(PowerSupply):
    """
    Class PowerSupplyPlus extends the basic functionality of class PowerSupply by:

    - XML file parser

    - timer (turn power supply on for a given period of time, thereafter turn output off)

    - voltage ramps (run voltage profiles)

    - current integrator (turn output off after a certain charge has been delivered)

    - power integrator (turn output off after a certain energy has been delivered)
    """

    @classmethod
    def parseXMLFile(cls, path=None):
        """
        Parse XML file an instantiate some instances of PowerSupplyPlus which are added to class variable "_instances" and also returned as a list.
        If no path to xml file is provided a file dialogue will open.
        """
        if path is None:
            log.info("ask user to provide setup configuration as XML")
            path = tk.filedialog.askopenfile(mode='r',title='Open Setup Configuration',filetypes=(('XML files','.xml'),('all files','*')))
        if path is None:
            log.info("action canelled by user")

        # discover all available wrappers for power supplies and load the modules dynamically
        cls.discoverWrappers()

        # trying to parse XML file
        log.info(f"parsing file {path.name}")
        tree = ET.parse(path)
        try:
          root = tree.getroot()
          log.debug(f"... found XML root. tag: {root.tag}")
        except:
          raise TypeError("XML root not found or faulty")

        for powsub in root.findall('powerSupply'):
            name  = powsub.get('name')
            model = powsub.get('model')

            # read power supply parameter
            for powsubParam in powsub.findall('port'):
                port = powsubParam.text


            # try to find a wrapper for the given model


            print(port)
            print(name)
            print(model)

        #print(path)
        return




    #############################################################################################
    # Constructor
    def __init__(self, name="PowerSupplyPlus",
                 channels=1):
        super().__init__(name=name,channels=channels) # call constructor of PowerSupply

        # list of threads
        self.threads = []
        self.stopThreads = threading.Event() # if stop event is set all threads will stop their loops

        # timer
        self._TimerCountdownTime = FloatList(name="TimerCountdownTime",data=[10.0]*self.numberOfChannels) # turn off output after N seconds
        self._TimerRunning = BoolList(name="TimerRunning",data=[False]*self.numberOfChannels)     # indicate whether or not a voltage ramp is running
        # potentially add a possibility to stop at a certain date & time ...

        # voltage ramp
        self._VRampVstart = self.Vmin.clone(name="VRampVstart") # voltage ramp start point
        self._VRampVend   = self.Vmin.clone(name="VRampVend") # voltage ramp end point
        self._VRampSteps  = IntList(name="VRampSteps",data=[100]*self.numberOfChannels)         # voltage ramp steps
        self._VRampDt     = FloatList(name="VRampDt",data=[0.1]*self.numberOfChannels)       # delay between the voltage steps in seconds
        self._VRampCycles = IntList(name="VRampCycles",data=[1]*self.numberOfChannels)           # repeats of the voltage ramp
        self._VRampUpAndDown = BoolList(name="VRampUpAndDown",data=[False]*self.numberOfChannels)   # ramp up and down (True) or just up (False)
        self._VRampRunning = BoolList(name="VRampRunning",data=[False]*self.numberOfChannels)     # indicate whether or not a voltage ramp is running
        self._VRampInterrampDelay  = FloatList(name="VRampInterrampDelay",data=[0.0]*self.numberOfChannels) # in case of full ramp this is the delay between ramping up and then down again
        self._VRampIntercycleDelay = FloatList(name="VRampIntercycleDelay",data=[0.0]*self.numberOfChannels) # in case of multiple cycles this is the delay between the cycles

        # current integrator -> to obtain the total charge
        self._IIntegDt     = FloatList(name="IIntegDt",data=[0.1]*self.numberOfChannels)  # time steps current integration in seconds
        self._IIntegCharge = FloatList(name="IIntegCharge",data=[0.0]*self.numberOfChannels)  # charge calculated from integrated current
        self._IIntegTstart = FloatList(name="IIntegTstart",data=[0.0]*self.numberOfChannels)  # time (seconds since epoch) when integration started
        self._IIntegRunning= BoolList(name="IIntegRunning",data=[False]*self.numberOfChannels) # indicate whether or not current integration is currently running
        self.IIntegMutex   = [threading.Lock()]*self.numberOfChannels       # make IIntegCharge thread save

        # power integrator -> to obtain the total energy output
        self._PowIntegDt      = FloatList(name="PowIntegDt",data=[0.1]*self.numberOfChannels)  # time steps for power integration in seconds
        self._PowIntegEnergy  = FloatList(name="PowIntegEnergy",data=[0.0]*self.numberOfChannels)  # energy calculated from integrated power
        self._PowIntegTstart  = FloatList(name="PowIntegTstart",data=[0.0]*self.numberOfChannels)  # time (seconds since epoch) when integration started
        self._PowIntegRunning = BoolList(name="PowIntegRunning",data=[False]*self.numberOfChannels) # indicate whether or not power integration is currently running
        self.PowIntegMutex    = [threading.Lock()]*self.numberOfChannels       # make PowIntegCharge thread save

        # register logger
        self.registerCallbacks()



    def registerCallbacks(self):
        """Register logger functions to property variables of the class which are of type LoggedList."""
        # register the logger as callback for the class variables in PowerSupply
        super().registerCallbacks()
        # now register logger to class variables additionally defined in PowerSupplyPlus
        self._TimerCountdownTime.register_callback(self.logger)
        self._TimerRunning.register_callback(self.logger)

        self._VRampVstart.register_callback(self.logger)
        self._VRampVend.register_callback(self.logger)
        self._VRampSteps.register_callback(self.logger)
        self._VRampDt.register_callback(self.logger)
        self._VRampCycles.register_callback(self.logger)
        self._VRampUpAndDown.register_callback(self.logger)
        self._VRampInterrampDelay.register_callback(self.logger)
        self._VRampIntercycleDelay.register_callback(self.logger)
        self._VRampRunning.register_callback(self.logger)

        self._IIntegDt.register_callback(self.logger)
        # self._IIntegCharge.register_callback(self.logger)  # for debugging purposes register a callback for this as well
        self._IIntegTstart.register_callback(self.logger)
        self._IIntegRunning.register_callback(self.logger)

        self._PowIntegDt.register_callback(self.logger)
        #self._PowIntegEnergy.register_callback(self.logger)  # for debugging purposes register a callback for this as well
        self._PowIntegTstart.register_callback(self.logger)
        self._PowIntegRunning.register_callback(self.logger)

    def stopAllThreads(self):
        """Stop all threads that might potentially be running (e.g. VoltageRamp, Timer, etc.)."""
        log.debug("sending stop event to threads")
        self.stopThreads.set() # send stop event
        for t in self.threads[:]: # iterate the list of threads
            log.debug(f"waiting for thread: {t.name} to join")
            t.join()
            log.debug(f"thread: {t.name} joined")
        self.threads.clear() # clear the list in order to make sure that all thread objects will be removed from memory

    @property
    def TimerRunning(self):
        return self._TimerRunning

    @TimerRunning.setter
    def TimerRunning(self, val):
        self._TimerRunning.set(val)


    @property
    def TimerCountdownTime(self):
        return self._TimerCountdownTime

    @TimerCountdownTime.setter
    def TimerCountdownTime(self, val):
        self._TimerCountdownTime.set(val)

    @property
    def VRampVstart(self):
        return self._VRampVstart

    @VRampVstart.setter
    def VRampVstart(self, val):
        self._VRampVstart.set(val)

    @property
    def VRampVend(self):
        return self._VRampVend

    @VRampVend.setter
    def VRampVend(self, val):
        self._VRampVend.set(val)

    @property
    def VRampSteps(self):
        return self._VRampSteps

    @VRampSteps.setter
    def VRampSteps(self, val):
        self._VRampSteps.set(val)

    @property
    def VRampDt(self):
        return self._VRampDt

    @VRampDt.setter
    def VRampDt(self, val):
        self._VRampDt.set(val)

    @property
    def VRampCycles(self):
        return self._VRampCycles

    @VRampCycles.setter
    def VRampCycles(self, val):
        self._VRampCycles.set(val)

    @property
    def VRampUpAndDown(self):
        return self._VRampUpAndDown

    @VRampUpAndDown.setter
    def VRampUpAndDown(self, val):
        self._VRampUpAndDown.set(val)

    @property
    def VRampRunning(self):
        return self._VRampRunning

    @VRampRunning.setter
    def VRampRunning(self, val):
        self._VRampRunning.set(val)

    @property
    def VRampInterrampDelay(self):
        return self._VRampInterrampDelay

    @VRampInterrampDelay.setter
    def VRampInterrampDelay(self, val):
        self._VRampInterrampDelay.set(val)

    @property
    def VRampIntercycleDelay(self):
        return self._VRampIntercycleDelay

    @VRampIntercycleDelay.setter
    def VRampIntercycleDelay(self, val):
        self._VRampIntercycleDelay.set(val)

    ### charge integrator properties
    @property
    def IIntegDt(self):
        return self._IIntegDt

    @IIntegDt.setter
    def IIntegDt(self,val):
        self._IIntegDt.set(val)

    @property
    def IIntegCharge(self):
        return self._IIntegCharge

    @IIntegCharge.setter
    def IIntegCharge(self,val):
        self._IIntegCharge.set(val)

    @property
    def IIntegTstart(self):
        return self._IIntegTstart

    @IIntegTstart.setter
    def IIntegTstart(self,val):
        self._IIntegTstart.set(val)

    @property
    def IIntegRunning(self):
        return self._IIntegRunning

    @IIntegRunning.setter
    def IIntegRunning(self,val):
        self._IIntegRunning.set(val)

    ### power integrator properties
    @property
    def PowIntegDt(self):
        return self._PowIntegDt

    @PowIntegDt.setter
    def PowIntegDt(self,val):
        self._PowIntegDt.set(val)

    @property
    def PowIntegEnergy(self):
        return self._PowIntegEnergy

    @PowIntegEnergy.setter
    def PowIntegEnergy(self,val):
        self._PowIntegEnergy.set(val)

    @property
    def PowIntegTstart(self):
        return self._PowIntegTstart

    @PowIntegTstart.setter
    def PowIntegTstart(self,val):
        self._PowIntegTstart.set(val)

    @property
    def PowIntegRunning(self):
        return self._PowIntegRunning

    @PowIntegRunning.setter
    def PowIntegRunning(self,val):
        self._PowIntegRunning.set(val)

    ### timer methods
    def timer(self, runtime, channel=0, callbacks=[]):
        """Start a timer and turn off output of the channel after time is up. Runtime in seconds"""
        tbegin = datetime.datetime.now()
        tnow = tbegin
        # indicate that the timer is running
        self.TimerRunning.set(new_data=True, index=channel)
        log.info(f"timer channel {channel} started, countdown {runtime}s")
        # wait until time is up
        while (tnow-tbegin).total_seconds() < runtime:
            tnow = datetime.datetime.now()
            time.sleep(1) # sleep one second
        # turn channel output off
        self.setOutputOff(channel=channel)

        # indicate that timer isn't running anymore
        self.logger(name="Timer Stopped",data=channel)
        self.TimerRunning.set(new_data=False, index=channel)
        log.info(f"timer channel {channel}, time is up, turn off output")

        # remove thread form list (if it is still init
        if threading.current_thread() in self.threads:
            self.threads.remove(threading.current_thread())
            log.debug(f"timer thread for channel {channel} removed from PowerSupplyPlus thread-list")

        # if callbacks are provided call them now
        for cb in callbacks:
            cb()

    def timerThreaded(self, channel=0, callbacks=[]):
        """
        Turn on the output of the selected channel.
        Start a timer with self._TimerCountdownTime[channel] as run-down time.
        When timer stops output will be turned off.
        """
        self.setOutputOn(channel=channel)
        timer = threading.Thread(target=self.timer, args=[self._TimerCountdownTime[channel], channel, callbacks])
        self.threads.append(timer) # add thread to list of threads
        timer.start()
        log.debug("started timer thread for channel "+str(channel))
        self.logger(name="Timer Started",data=channel)

    def timerCalculateStopDateAndTime(self, channel=0):
        """
        Helper method that returns the time when the timer that is started now would switch power supply output off.
        time string format is: YYYY/MM/DD-HH:MM:SS
        """
        tend = datetime.datetime.now()+datetime.timedelta(seconds=self._TimerCountdownTime[channel])
        return tend.strftime('%Y/%m/%d-%H:%M:%S')

    ### voltage ramp methods
    def voltageRamp(self, channel=0):
        """
        Ramp up (and down) voltages in steps.
        This procedure is useful for measuring I-V and other characteristics.
        Method uses setVoltage() and does not need to be over-ridden.
        """
        if self.VRampVstart[channel]<self.Vmin[channel] \
            or self.VRampVstart[channel]>self.Vmax[channel] \
            or self.VRampVend[channel]<self.Vmin[channel] \
            or self.VRampVend[channel]>self.Vmax[channel]:
            log.info("cannot run a voltage ramp with given Vstart ("+str(self.VRampVstart)+"V) and Vend ("+str(self.VRampVend)+"V) - they are out of range ("+str(self.Vmin[channel].get())+"V, "+str(self.Vmax[channel].get())+"V)")
            return

        dV = (self.VRampVend[channel]-self.VRampVstart[channel])/self.VRampSteps[channel]
        V  = self.VRampVstart[channel]

        rp  = 0
        # if a callback is registered for instance a button text can be changed to "Stop" to indicate that a ramp is running
        self.VRampRunning.set(new_data=True, index=channel)
        log.debug("voltage ramp started in channel "+str(channel))

        # start the ramp
        while rp<self.VRampCycles[channel] and self.VRampRunning[channel] and not self.stopThreads.is_set(): # stop after the given number of repetitions or if "stop" flag is set
            # ramp up
            for step in range(0,self.VRampSteps[channel]+1):
                self.setVoltage(V,channel=channel,logLevel=logging.DEBUG) # logLevel set to debug in order not to show every step in the log
                V += dV
                time.sleep(self.VRampDt[channel])
                if not self.VRampRunning[channel]: break # if user pressed "stop" -> stop here
            # ramp down
            if self.VRampUpAndDown[channel]:
                time.sleep(self.VRampInterrampDelay[channel])
                for step in range(0,self.VRampSteps[channel]+1):
                    V -= dV
                    self.setVoltage(V,channel=channel,logLevel=logging.DEBUG) # logLevel set to debug in order not to show every step in the log
                    time.sleep(self.VRampDt[channel])
                    if not self.VRampRunning[channel]: break # if user pressed "stop" -> stop here
            time.sleep(self.VRampIntercycleDelay[channel])
            V=self.VRampVstart[channel]
            rp += 1

        # indicate that voltage ramp isn't running anymore
        self.VRampRunning.set(new_data=False, index=channel)
        log.debug("voltage ramp stopped in channel "+str(channel))

        # remove thread form list (if it is still init
        if threading.current_thread() in self.threads:
            self.threads.remove(threading.current_thread())
            log.debug("voltage ramp thread removed from PowerSupplyPlus thread-list")
        return

    def voltageRampThreaded(self,channel=0): # output channel of the power supply
        """Run method voltageRamp() as a separate thread"""
        VRampThread = threading.Thread(target=self.voltageRamp, args=(channel,))
        self.threads.append(VRampThread) # add thread to list of threads
        VRampThread.start()
        log.debug("voltage ramp thread started for channel "+str(channel))
        return VRampThread

    ### integration methods
    def integrateCurrent(self,channel=0): # channel -> output channel of the power supply
        """
        Integrate the current output of the given channel.
        The total charge can be obtained from IIntegCharge[channel] at any time.
        The function is made thread-save by using a mutex (IIntegMutex).
        """
        if self.IIntegRunning[channel]: # if current integration is already running, do nothing
            return
        log.info(f"current integration started for channel {channel}")
        # indicate that current integration is running for this channel
        self.IIntegRunning.set(True,index=channel)
        # get and set start time
        self.IIntegTstart.set(time.time(),index=channel)
        t     = self.IIntegTstart[channel] # initialse time
        tprev = self.IIntegTstart[channel] # initialse previous time
        (I, dC) = (0.0,0.0) # initialse current reading and delta charge
        # reset charge
        self.IIntegCharge.set(0.0,index=channel)

        while self.IIntegRunning[channel] and not self.stopThreads.is_set():
            # get current reading
            I=self.getCurrent(channel)
            # get time
            t=time.time()
            # calculate dC
            dC=I*(t-tprev)
            # add dC to total charge, use mutex to make it thread-save
            with self.IIntegMutex[channel]:
                self._IIntegCharge += (dC,channel)
            # set time for next cycle
            tprev = t
            # wait
            time.sleep(self.IIntegDt[channel])
        log.info(f"current integration stopped for channel {channel}")

        # remove thread form list (if it is still in it)
        if threading.current_thread() in self.threads:
            self.threads.remove(threading.current_thread())
            log.debug("current integration thread removed from PowerSupplyPlus thread-list")
        return

    def integrateCurrentThreaded(self,channel=0): # output channel of the power supply
        """Run method integrateCurrent() as a separate thread"""
        IIntThread = threading.Thread(target=self.integrateCurrent, args=(channel,))
        self.threads.append(IIntThread) # add thread to list of threads
        IIntThread.start()
        log.debug("integrate current thread started for channel "+str(channel))
        return IIntThread

    def integratePower(self,channel=0):
        """
        Integrate the power output of the given channel to obtain the energy that was supplied.
        The total energy can be obtained from PowIntegEnergy[channel] at any time.
        """
        if self.PowIntegRunning[channel]: # if current integration is already running, do nothing
            return
        # indicate that power integration is running for this channel
        self.PowIntegRunning.set(True,index=channel)
        # get and set start time
        self.PowIntegTstart.set(time.time(),index=channel)
        t     = self.PowIntegTstart[channel] # initialse time
        tprev = self.PowIntegTstart[channel] # initialse previous time
        (P, dE) = (0.0,0.0) # initialse current reading and delta charge
        # reset charge
        self.PowIntegEnergy.set(0.0,index=channel)

        while self.PowIntegRunning[channel] and not self.stopThreads.is_set():
            # get output power from power supply
            P=self.getPower(channel)
            # get time
            t=time.time()
            # calculate dC
            dE=P*(t-tprev)
            # add dE to total energy, use mutex to make it thread-save
            with self.PowIntegMutex[channel]:
                self._PowIntegEnergy += (dE,channel)
            # set time for next cycle
            tprev = t
            # wait
            time.sleep(self.PowIntegDt[channel])

        log.debug(f"power integration stopped for channel {channel}")

        # remove thread form list (if it is still init
        if threading.current_thread() in self.threads:
            self.threads.remove(threading.current_thread())
            log.debug("power integration thread removed from PowerSupplyPlus thread-list")
        return

    def integratePowerThreaded(self,channel=0): # output channel of the power supply
        """Run method integratePower() as a separate thread"""
        PowIntThread = threading.Thread(target=self.integratePower, args=(channel,))
        self.threads.append(PowIntThread) # add thread to list of threads
        PowIntThread.start()
        log.debug("integrate power thread started for channel "+str(channel))
        return PowIntThread


class PowerSupplyGUI(tk.Frame):
    """
    Graphical user interface for PowerSupply / PowerSupplyPlus.
    The GUI is set up dynamically providing N panels for the N channels of the power supply.
    Each channel control consists of a panel with the basic controls:

    - set points for voltage and current

    - displays of current readings

    - output on/off switch.

    Furthermore, there are tabs for the more sophisticated functionality provided by PowerSupplyPlus:

    - timer (turn output on, wait, turn off)

    - voltage ramps (cycles of: ramp up voltage in steps, wait (optional), ramnp voltage down, wait (optional))

    - current integrator (display the total charge provided and optionally turn output off when a certain charge is reached)

    - power integrator (display the totla energy provided and optionally turn output off at a certain value)

    Also the GUI allows for logging:

    - the user actions

    - write a complete session log

    - and save the data of the entire session
    """

    # static variables
    panelBasicDimensions       = [5,4] # [columns, rows]
    panelActionTabDimensions   = [5,4] # [columns, rows]
    panelSaveDataDimensions    = [4,4] # [columns, rows]


    #############################################################################################
    # Constructor
    def __init__(self,
                 powSupPl, # a PowerSupplyPlus object has to be provided
                 master=None
                 ):
        # link to an instance of PowerSupplyPlus
        self.powerSupply = powSupPl

        # list of threads
        self.threads = []
        self.stopThreads = threading.Event() # if stop event is set all threads will stop their loops

        # list of windows
        self.windows = []

        # agreement on static instance variables
        self.windowName = tk.StringVar(master,self.powerSupply.name)
        self.windowName.trace('w',self.setWindowTitle) # if name changes the window title will be updated automatically
        self.channelDescription = [tk.StringVar(master,des) for des in self.powerSupply.description]

        # agreement on dynamic instance variables
        # basic
        self.Vreading    = []  # actual voltage reading from the power supply
        self.Ireading    = []  # actual current reading from the power supply

        for i in range(0,self.powerSupply.numberOfChannels):
          self.Vreading.append(tk.DoubleVar(master,0.0))
          self.Ireading.append(tk.DoubleVar(master,0.0))

        # save data
        self.saveDataAutosave   = tk.BooleanVar(master,False) # indicates that data will be automatically saved
        self.saveDataSaveLog    = tk.BooleanVar(master,False) # indicates that data will be automatically saved
        self.saveDataAutosaveDt = tk.DoubleVar(master,10)  # period at which data is auto-saved (in seconds)
        self.saveDataFileName   = tk.StringVar(master,"")     # name of file to which data is saved

        # everything can be logged ...
        self.powerSupplyDataLoggerOn = True # if set False no logging is happening - and data can't be saved
        self.powerSupplyDataLog = []        # list that is being filled when logging is turned on
        for v in self.Vreading: v.trace('w',self.powerSupplyDataLogger)
        for i in self.Ireading: i.trace('w',self.powerSupplyDataLogger)

        # variables basic panels
        self.entrySetpointVoltage   = [None]*self.powerSupply.numberOfChannels # voltage set-point entry -> is writing to self.Vset
        self.entrySetpointCurrent   = [None]*self.powerSupply.numberOfChannels # current set-point entry -> is writing to self.Iset
        self.buttonSetpoint         = [None]*self.powerSupply.numberOfChannels # set voltage and current when clicked
        self.checkButtonOutputOnOff = [None]*self.powerSupply.numberOfChannels # turn output of that channel on/off
        self.checkButtonOutputOnOffState = [None]*self.powerSupply.numberOfChannels # state of the checkbutton as IntVar

        ###### variables action tabs
        # variables timer
        self.entryTimerCountdown = [None]*self.powerSupply.numberOfChannels
        self.timeUnits           = ["seconds", "minutes", "hours", "days"]
        self.comboboxTimerUnits  = [None]*self.powerSupply.numberOfChannels
        self.lblCountDownFinish  = [None]*self.powerSupply.numberOfChannels # label displaying the end time after a timer is started
        self.buttonTimerRun      = [None]*self.powerSupply.numberOfChannels # button to start timer
        self.buttonTimerRunText  = [] # list enties for each channel, text filled dynamically; Run -> Stop

        # variables voltage ramp
        self.entryVRampVstart = [None]*self.powerSupply.numberOfChannels # start voltage for ramp
        self.entryVRampVend   = [None]*self.powerSupply.numberOfChannels # end voltage for ramp
        self.buttonVRampRun   = [None]*self.powerSupply.numberOfChannels # start voltage ramp
        self.buttonVRampRunText = []


        self.buttonVRampRunText  = []  # text on voltage ramp run-button
        self.entryVRampSteps  = [None]*self.powerSupply.numberOfChannels # steps in which the voltage is ramped up (and down)
        self.entryVRampDt     = [None]*self.powerSupply.numberOfChannels # delay between the voltage steps
        self.entryVRampCycles = [None]*self.powerSupply.numberOfChannels # repeats of the voltage ramp
        self.entryVRampInterrampDelay  = [None]*self.powerSupply.numberOfChannels # delay between ramp up and down again
        self.entryVRampIntercycleDelay = [None]*self.powerSupply.numberOfChannels # delay between cycles
        self.checkButtonVRampFullRamp  = [None]*self.powerSupply.numberOfChannels # ramp voltage up and down again?

        # variables current integrator
        self.buttonIIntegStart           = [None]*self.powerSupply.numberOfChannels # start current integration
        self.buttonIIntegStartText       = [] # start current integration button label
        self.entryIIntegMaxCharge        = [None]*self.powerSupply.numberOfChannels # user can indicate a maximum charge to be reached
        self.checkButtonIIntegOutputOff  = [None]*self.powerSupply.numberOfChannels # turn power supply output off after a maximum charge is reached?
        self.lblIIntegCharge             = [None]*self.powerSupply.numberOfChannels # indicator for the integrated current / charge
        self.IIntegCharge                = [] # text to be displayed in lblIIntegCharge

        # variables power integrator
        self.buttonPowIntegStart           = [None]*self.powerSupply.numberOfChannels # start current integration
        self.buttonPowIntegStartText       = [] # start current integration button label
        self.entryPowIntegMaxEnergy        = [None]*self.powerSupply.numberOfChannels # user can indicate a maximum energy to be reached
        self.checkButtonPowIntegOutputOff  = [None]*self.powerSupply.numberOfChannels # turn power supply output off after a maximum energy is reached?
        self.lblPowIntegEnergy             = [None]*self.powerSupply.numberOfChannels # indicator for the integrated power
        self.PowIntegEnergy                = [] # text to be displayed in lblPowIntegPower


        # multi-threaded reading of values from power supply
        self.mutex = threading.Lock()
        self.readVoltageAndCurrentValues = True # the thread that is permanently asking the power supply about V and I can be stopped when set False

        # initialise GUI on TKinter.Frame level
        log.debug("setting up power supply GUI")
        tk.Frame.__init__(self,master)

        self.grid(padx=5, pady=5,)
        self.master.title(self.windowName.get())
        self.master.protocol("WM_DELETE_WINDOW", self.onClosing) # run exit sequence if user clicks "X"


        # setup a menubar
        log.debug("... setting up menu bar")
        self.setupMenuBar()

        # setup panels for the different channels
        for ch in range(0,self.powerSupply.numberOfChannels):
            log.debug(f"... setting up panel for channel {ch}")
            # send output off to power supply
            log.debug(f"...... send channel {ch} output off")
            self.powerSupply.setOutputOff(ch)
            # set up basic functionality panel
            log.debug(f"...... setting up basic panel for channel {ch}")
            self.panelBasic = self.setupPanelBasic(channel=ch)
            self.panelBasic.grid(padx=5, pady=5,
                    row=1,
                    column=ch*PowerSupplyGUI.panelBasicDimensions[0],sticky="nesw")

            # set up action tab panel
            log.debug(f"...... setting up action tab panel for channel {ch}")
            self.panelActionTabs = self.setupPanelActionTabs(channel=ch)
            self.panelActionTabs.grid(padx=5, pady=5,
                    row=1+PowerSupplyGUI.panelBasicDimensions[1],
                    column=ch*PowerSupplyGUI.panelActionTabDimensions[0], sticky="nesw")

        # start the value reader thread to update voltage and current reads in the GUI
        log.debug("... start value reader thread")
        self.readValuesThreaded(interval=0.5)

        log.debug("finished setting up GUI")
        return

    #############################################################################################


    ### GUI methods

    def remove_window(self,window):
        """Remove window from window list if user clicks "x"."""
        if window in self.windows:
            self.windows.remove(window)
        window.destroy()

    def onClosing(self, askUserConfirmation=True):
        """
        Exit sequence.
        If user clicks "X" in main-window run this routine.
        """
        if askUserConfirmation:
            log.info("user clicked exit")
            if messagebox.askquestion("Exit Application", "Do you really want to exit?") == "no":
                log.info("exit cancelled")
                return

        log.info("running exit sequence")

        # stop all threads in self.powerSupply
        log.info("stopping power supply action threads")
        self.powerSupply.stopAllThreads()
        log.info("threads stopped")

        # ramping down voltages and turn output off
        for channel in range(0,self.powerSupply.numberOfChannels):
            log.info("ramping down voltage of channel "+str(channel))
            while abs(self.powerSupply.Vset[channel])>0.05:
                V = self.powerSupply.Vset[channel]*0.9
                self.powerSupply.setVoltage(V=V,channel=channel,logLevel=logging.DEBUG)
            self.powerSupply.setOutputOff(channel=channel)
            log.info("done")

        # stop all GUI threads
        log.info("sending stop event to GUI threads")
        self.stopThreads.set() # send stop event
        for t in self.threads[:]: # iterate the list of threads
            log.debug(f"waiting for thread: {t.name} to join")
            t.join()
            log.debug(f"thread: {t.name} joined")
        self.threads.clear() # clear the list in order to make sure that all thread objects will be removed from memory

        # disconnect power supply
        log.info("disconnect power supply")
        del self.powerSupply
        log.info("power supply disconnected")

        # close all open windows
        for window in self.windows:
            try:
              window.destroy()
            except:
              pass

        # close GUI
        log.info("close GUI")
        self.master.destroy() # master is necessary because otherwise only the frame of the window will be destroyed but not the window itself
        return


    def setupMenuBar(self):
        """
        This method sets up the menu bar for the GUI.
        Menus:

        - File

        - Settings

        - Logger

        - About

        """
        menubar = tk.Menu(self)
        filemenu = tk.Menu(menubar,tearoff=0)
        filemenu.add_command(label="Save Data",command=self.saveData)
        filemenu.add_command(label="Exit",command=self.onClosing)
        menubar.add_cascade(label="File",menu=filemenu)

        # logging

        loggingmenu = tk.Menu(menubar,tearoff=0)
        loggingmenu.add_command(label="View Session Log",command=self.menuLoggingShowSessionLog)
        loggingmenu.add_command(label="Plot Session Log",command=self.menuLoggingPlotSessionLog)
        loggingmenu.add_command(label="Clear Session Log",command=self.menuLoggingClearSessionLog)

        menubar.add_cascade(label="Logging",menu=loggingmenu)

        # settings

        settingsmenu = tk.Menu(menubar,tearoff=0)

        for ch in range(0,self.powerSupply.numberOfChannels):
          lbl = "limits channel "+str(ch)
          settingsmenu.add_command(label=lbl,command=lambda ch=ch: self.menuSettingsChannelLimits(ch))
          # Note: the ch=ch is an initialisation of lamba function.
          # Without it menuSettingsChannel would always be called with ch=numberOfChannels-1.

        menubar.add_cascade(label="Settings",menu=settingsmenu)

        # about

        aboutmenu = tk.Menu(menubar,tearoff=0)
        aboutmenu.add_command(label="About",command=self.menuAbout)
        menubar.add_cascade(label="About",menu=aboutmenu)

        self.master.config(menu=menubar)

    def setupPanelBasic(self,channel=0):
        """
        Method sets up and returns the panel for basic functionality for the frame.
        """

        frame = tk.Frame(self, padx=5, pady=5,bd=1, relief="groove")
        frame.grid(padx=5,row=0,column=7,sticky="nesw")

        # power supply description
        lblPSDescription  = tk.Label(frame, textvariable=self.channelDescription[channel], relief="sunken",padx=10, justify="left")
        lblPSDescription.grid(row=0,column=0, sticky="nesw", columnspan=6)

        # set-point (voltage and current)
        tk.Label(frame, text="set-point:",anchor="w",justify="left").grid(row=3,column=0, sticky="w",padx=10)
        self.entrySetpointVoltage[channel]  = tk.Entry(frame, relief="sunken", width=6, justify="right")
        self.entrySetpointVoltage[channel].grid(row=3,column=1, sticky="nesw")
        self.entrySetpointVoltage[channel].bind('<Return>',lambda event: self.entrySetpointVoltage_returnPressed(channel))
        self.entrySetpointVoltage[channel].delete(0,tk.END)
        self.entrySetpointVoltage[channel].insert(0,str(self.powerSupply.Vset[channel])) # set initial value
        tk.Label(frame, text="V",anchor="w",justify="left").grid(row=3,column=2, sticky="w",padx=10)

        self.entrySetpointCurrent[channel]  = tk.Entry(frame, relief="sunken", width=6, justify="right")
        self.entrySetpointCurrent[channel].grid(row=3,column=3, sticky="nesw")
        self.entrySetpointCurrent[channel].bind('<Return>', lambda event: self.entrySetpointCurrent_returnPressed(channel))
        self.entrySetpointCurrent[channel].delete(0,tk.END)
        self.entrySetpointCurrent[channel].insert(0,str(self.powerSupply.Vset[channel])) # set initial value
        tk.Label(frame, text="A",anchor="w",justify="left").grid(row=3,column=4, sticky="w",padx=10)

        self.buttonSetpoint[channel] = tk.Button(frame,text="Set",pady=10)
        self.buttonSetpoint[channel].grid(row=2,column=5,sticky="nesw",rowspan=2)
        self.buttonSetpoint[channel].bind('<Button-1>',lambda event: self.buttonSetpoint_pressed(channel))

        # actual voltage and current values
        tk.Label(frame, text="readings:",anchor="w",justify="left").grid(row=4,column=0, sticky="w",padx=10)
        tk.Label(frame, textvariable=self.Vreading[channel],anchor="w",justify="right").grid(row=4,column=1, sticky="e")
        tk.Label(frame, text="V",anchor="w",justify="left").grid(row=4,column=2, sticky="w",padx=10)
        tk.Label(frame, textvariable=self.Ireading[channel],anchor="w",justify="right").grid(row=4,column=3, sticky="e")
        tk.Label(frame, text="A",anchor="w",justify="left").grid(row=4,column=4, sticky="w",padx=10)

        # output on/off checkbutton
        self.checkButtonOutputOnOffState[channel] = tk.BooleanVar()
        self.checkButtonOutputOnOff[channel] = tk.Checkbutton(frame, text="output", onvalue=True, offvalue=False, variable=self.checkButtonOutputOnOffState[channel])
        self.checkButtonOutputOnOff[channel].grid(row=4,column=5,sticky="nesw",rowspan=2)
        self.checkButtonOutputOnOff[channel].bind('<Button-1>',lambda event: self.turnOutputOnOff(channel))
        self.checkButtonOutputOnOffState[channel].set(False)

        return frame

    def setupPanelActionTabs(self,channel=0):
        """
        Method that sets up a panel with multiple tabs each containing some advanced funtionality, e.g.
        - timer
        - voltage ramp
        - current integrator
        - voltage integrator
        """
        notebook = ttk.Notebook(self)
        notebook.grid(padx=5,row=0,column=0, sticky="nesw", columnspan=2)

        # make tab timer
        tabTimer = ttk.Frame(notebook)
        notebook.add(tabTimer, text="Timer")
        panelTimer = self.setupPanelTimer(tabTimer,channel)
        panelTimer.pack(pady=0, padx=0)

        # make tab voltage ramp
        tabVRamp = ttk.Frame(notebook)
        notebook.add(tabVRamp, text="Voltage Ramp")
        panelVRamp = self.setupPanelVRamp(tabVRamp,channel)
        panelVRamp.pack(pady=0, padx=0)

        # make tab current integrator
        tabCurrentIntegrator = ttk.Frame(notebook)
        notebook.add(tabCurrentIntegrator, text="Current integrator")
        panelCurrInt = self.setupPanelCurrentIntegrator(tabCurrentIntegrator,channel)
        panelCurrInt.pack(pady=0, padx=0)

        # make tab power integrator
        tabPowerIntegrator = ttk.Frame(notebook)
        notebook.add(tabPowerIntegrator, text="Power integrator")
        panelPowerInt = self.setupPanelPowerIntegrator(tabPowerIntegrator,channel)
        panelPowerInt.pack(pady=0, padx=0)

        return notebook

    def setupPanelTimer(self,tab,channel=0):
        """
        Method sets up and returns the panel for the timer control of the power supply output.
        """
        frame = tk.Frame(tab, padx=10, pady=10,bd=1, relief="flat")
        frame.grid(padx=5,row=0,column=7,rowspan=4,sticky="nesw")
        lblCountDown = tk.Label(frame, text="countdown time", relief="flat", padx=10, justify="left")
        lblCountDown.grid(row=0,column=0, sticky="nw")

        self.entryTimerCountdown[channel] = tk.Entry(frame, relief="sunken", width=12, justify="right")
        self.entryTimerCountdown[channel].grid(row=0, column=1, sticky="nesw")
        self.entryTimerCountdown[channel].insert(0,"10.0") # give an initial value
        self.comboboxTimerUnits[channel]  = ttk.Combobox(frame, values=self.timeUnits, state="readonly", width=8)
        self.comboboxTimerUnits[channel].grid(padx=10,row=0, column=2, sticky="nesw")
        self.comboboxTimerUnits[channel].set(self.timeUnits[0])

        lblCountDownFinish = tk.Label(frame, text="countdown will end on:", relief="flat", padx=10,justify="left")
        lblCountDownFinish.grid(row=1, column=0, sticky="nw")

        # string to indicate the end time when timer is started
        self.lblCountDownFinish[channel] = tk.Label(frame, text="", relief="flat", padx=10, justify="left")
        self.lblCountDownFinish[channel].grid(row=2, column=0, sticky="nw", columnspan=2)

        # timer start button
        self.buttonTimerRunText.append(tk.StringVar(frame,"Run"))
        self.buttonTimerRun[channel] = tk.Button(frame,textvariable=self.buttonTimerRunText[channel],pady=10,
                                    command=lambda: self.buttonTimerRun_pressed(channel) )
        self.buttonTimerRun[channel].grid(row=2,column=2,sticky="nesw")

        return frame


    def setupPanelVRamp(self,tab,channel=0):
        """
        Method sets up and returns the panel for voltage ramp functionality for given channel.
        """
        frame = tk.Frame(tab, padx=10, pady=10,bd=1, relief="flat")
        frame.grid(padx=5,row=0,column=7,rowspan=4,sticky="nesw")

        lblVoltRamp  = tk.Label(frame, text="voltage ramp", relief="flat",padx=10, justify="left")
        lblVoltRamp.grid(row=0,column=0, sticky="nesw", columnspan=2)

        lblRange = tk.Label(frame, text="range:", relief="flat",padx=10, justify="left")
        lblRange.grid(row=1,column=0, sticky="w")

        self.entryVRampVstart[channel]  = tk.Entry(frame, relief="sunken", width=6, justify="right")
        self.entryVRampVstart[channel].grid(row=1,column=1, sticky="nesw")
        self.entryVRampVstart[channel].bind('<Return>', lambda event: self.entryVRampVstart_returnPressed(channel))
        self.entryVRampVstart[channel].insert(0,str(self.powerSupply.VRampVstart[channel]))

        lblVRampVstartUnit = tk.Label(frame, text="V", relief="flat",padx=10, justify="left")
        lblVRampVstartUnit.grid(row=1,column=2, sticky="w")

        self.entryVRampVend[channel]  = tk.Entry(frame, relief="sunken", width=6, justify="right")
        self.entryVRampVend[channel].grid(row=1,column=3, sticky="nesw")
        self.entryVRampVend[channel].bind('<Return>', lambda event: self.entryVRampVend_returnPressed(channel))
        self.entryVRampVend[channel].insert(0,str(self.powerSupply.VRampVend[channel]))

        lblVRampVendUnit = tk.Label(frame, text="V", relief="flat",padx=10, justify="left")
        lblVRampVendUnit.grid(row=1,column=4, sticky="w", columnspan=1)

        self.buttonVRampRunText.append(tk.StringVar(frame,"Run"))
        self.buttonVRampRun[channel] = tk.Button(frame,textvariable=self.buttonVRampRunText[channel],pady=10,
                                    command=lambda: self.buttonVRampRun_pressed(channel) )
        self.buttonVRampRun[channel].grid(row=0,column=5,sticky="nesw",rowspan=2)

        lblSteps = tk.Label(frame, text="steps:", relief="flat",padx=10, justify="left")
        lblSteps.grid(row=2,column=0, sticky="w")

        self.entryVRampSteps[channel]  = tk.Entry(frame, relief="sunken", width=6, justify="right")
        self.entryVRampSteps[channel].grid(row=2,column=1, sticky="nesw")
        self.entryVRampSteps[channel].bind('<Return>', lambda event: self.entryVRampSteps_returnPressed(channel))
        self.entryVRampSteps[channel].insert(0,str(self.powerSupply.VRampSteps[channel]))

        lbldt = tk.Label(frame, text="dt:", relief="flat",padx=10, justify="left")
        lbldt.grid(row=2,column=2, sticky="e")

        self.entryVRampDt[channel]  = tk.Entry(frame, relief="sunken", width=6, justify="right")
        self.entryVRampDt[channel].grid(row=2,column=3, sticky="nesw")
        self.entryVRampDt[channel].bind('<Return>', lambda event: self.entryVRampDt_returnPressed(channel))
        self.entryVRampDt[channel].insert(0,str(self.powerSupply.VRampDt[channel]))

        lblCycles = tk.Label(frame, text="cycles:", relief="flat",padx=10, justify="left")
        lblCycles.grid(row=2,column=4, sticky="e")

        self.entryVRampCycles[channel]  = tk.Entry(frame, relief="sunken", width=6, justify="right")
        self.entryVRampCycles[channel].grid(row=2,column=5, sticky="nesw")
        self.entryVRampCycles[channel].bind('<Return>', lambda event: self.entryVRampCycles_returnPressed(channel))
        self.entryVRampCycles[channel].insert(0,str(self.powerSupply.VRampCycles[channel]))

        lblDelays = tk.Label(frame, text="delays (seconds):", relief="flat",padx=10, justify="left")
        lblDelays.grid(row=3,column=0, sticky="w",columnspan=2)

        lblInterrampDelay = tk.Label(frame, text="ramp:", relief="flat",padx=10, justify="left")
        lblInterrampDelay.grid(row=3,column=2, sticky="e")

        self.entryVRampInterrampDelay[channel] = tk.Entry(frame, relief="sunken", width=6, justify="right")
        self.entryVRampInterrampDelay[channel].grid(row=3,column=3, sticky="nesw")
        self.entryVRampInterrampDelay[channel].bind('<Return>', lambda event: self.entryVRampInterrampDelay_returnPressed(channel))
        self.entryVRampInterrampDelay[channel].insert(0,str(self.powerSupply.VRampInterrampDelay[channel]))

        lblIntercycleDelay = tk.Label(frame, text="cycle:", relief="flat",padx=10, justify="left")
        lblIntercycleDelay.grid(row=3,column=4, sticky="e")

        self.entryVRampIntercycleDelay[channel] = tk.Entry(frame, relief="sunken", width=6, justify="right")
        self.entryVRampIntercycleDelay[channel].grid(row=3,column=5, sticky="nesw")
        self.entryVRampIntercycleDelay[channel].bind('<Return>', lambda event: self.entryVRampIntercycleDelay_returnPressed(channel))
        self.entryVRampIntercycleDelay[channel].insert(0,str(self.powerSupply.VRampIntercycleDelay[channel]))

        self.checkButtonVRampFullRamp[channel] = tk.ttk.Checkbutton(frame, text="full ramp")
        self.checkButtonVRampFullRamp[channel].grid(row=0,column=3,sticky="w",columnspan=3)
        self.checkButtonVRampFullRamp[channel].state(['!selected'])
        self.checkButtonVRampFullRamp[channel].bind('<Button-1>',lambda event: self.checkButtonVRampFullRamp_ticked(channel))
        self.checkButtonVRampFullRamp[channel].invoke()
        self.checkButtonVRampFullRamp_ticked(channel)

        return frame

    def setupPanelCurrentIntegrator(self, tab, channel):
        """
        Method sets up and returns the panel for current integration functionality for given channel.
        """
        frame = tk.Frame(tab, padx=10, pady=10,bd=1, relief="flat")
        frame.grid(padx=5,row=0,column=7,rowspan=4,sticky="nesw")

        lblIIntegChargeText = tk.Label(frame, text="integrated current (charge)", relief="flat",padx=10, justify="right")
        lblIIntegChargeText.grid(row=0,column=0, sticky="e")

        self.IIntegCharge.append(tk.StringVar(frame,"0.0"))
        self.lblIIntegCharge[channel] = tk.Label(frame, textvariable=self.IIntegCharge[channel], relief="flat",padx=10, justify="right")
        self.lblIIntegCharge[channel].grid(row=0,column=1, sticky="e")

        lblIIntegChargeUnit = tk.Label(frame, text="As", relief="flat",padx=10, justify="left")
        lblIIntegChargeUnit.grid(row=0,column=2, sticky="nw",padx=5)

        lblIIntegMaxChargeText = tk.Label(frame, text="output off at", relief="flat",padx=10, justify="right")
        lblIIntegMaxChargeText.grid(row=1,column=0, sticky="e")

        self.entryIIntegMaxCharge[channel] = tk.Entry(frame, relief="sunken", width=8, justify="right")
        self.entryIIntegMaxCharge[channel].grid(row=1,column=1, sticky="nesw")
        self.entryIIntegMaxCharge[channel].insert(0,"1.0")

        lblIIntegMaxChargeUnit = tk.Label(frame, text="As", relief="flat",padx=10, justify="left")
        lblIIntegMaxChargeUnit.grid(row=1,column=2, sticky="nw",padx=5)

        self.checkButtonIIntegOutputOff[channel] = tk.ttk.Checkbutton(frame, text="output off at max. charge?")
        self.checkButtonIIntegOutputOff[channel].grid(row=2,column=0,sticky="e",columnspan=2,padx=10)
        self.checkButtonIIntegOutputOff[channel].state(['!selected'])
        self.checkButtonIIntegOutputOff[channel].bind('<Button-1>',lambda event: self.checkButtonIIntegOutputOff_ticked(channel))
        self.checkButtonIIntegOutputOff[channel].invoke()

        self.buttonIIntegStartText.append(tk.StringVar(frame,"Run"))
        self.buttonIIntegStart = tk.Button(frame,textvariable=self.buttonIIntegStartText[channel],pady=5,padx=10,
                                    command=lambda: self.buttonIIntegStart_pressed(channel) )
        self.buttonIIntegStart.grid(row=2,column=2,columnspan=1,padx=5)

        return frame

    def setupPanelPowerIntegrator(self, tab, channel):
        """
        Method sets up and returns the panel for power integration functionality for given channel.
        """
        frame = tk.Frame(tab, padx=10, pady=10,bd=1, relief="flat")
        frame.grid(padx=5,row=0,column=7,rowspan=4,sticky="nesw")

        lblPowIntegEnergyText = tk.Label(frame, text="integrated power (energy)", relief="flat",padx=10, justify="right")
        lblPowIntegEnergyText.grid(row=0,column=0, sticky="e")

        self.PowIntegEnergy.append(tk.StringVar(frame,"0.0"))
        self.lblPowIntegEnergy[channel] = tk.Label(frame, textvariable=self.PowIntegEnergy[channel], relief="flat",padx=10, justify="right")
        self.lblPowIntegEnergy[channel].grid(row=0,column=1, sticky="e")

        lblPowIntegEnergyUnit = tk.Label(frame, text="Ws", relief="flat",padx=10, justify="left")
        lblPowIntegEnergyUnit.grid(row=0,column=2, sticky="nw",padx=5)

        lblPowIntegMaxEnergyText = tk.Label(frame, text="output off at", relief="flat",padx=10, justify="right")
        lblPowIntegMaxEnergyText.grid(row=1,column=0, sticky="e")

        self.entryPowIntegMaxEnergy[channel] = tk.Entry(frame, relief="sunken", width=8, justify="right")
        self.entryPowIntegMaxEnergy[channel].grid(row=1,column=1, sticky="nesw")
        self.entryPowIntegMaxEnergy[channel].insert(0,"1.0")

        lblPowIntegMaxEnergyUnit = tk.Label(frame, text="Ws", relief="flat",padx=10, justify="left")
        lblPowIntegMaxEnergyUnit.grid(row=1,column=2, sticky="nw",padx=5)

        self.checkButtonPowIntegOutputOff[channel] = tk.ttk.Checkbutton(frame, text="output off at max. energy?")
        self.checkButtonPowIntegOutputOff[channel].grid(row=2,column=0,sticky="e",columnspan=2,padx=10)
        self.checkButtonPowIntegOutputOff[channel].state(['!selected'])
        self.checkButtonPowIntegOutputOff[channel].bind('<Button-1>',lambda event: self.checkButtonPowIntegOutputOff_ticked(channel))
        self.checkButtonPowIntegOutputOff[channel].invoke()

        self.buttonPowIntegStartText.append(tk.StringVar(frame,"Run"))
        self.buttonPowIntegStart = tk.Button(frame,textvariable=self.buttonPowIntegStartText[channel],pady=5,padx=10,
                                    command=lambda: self.buttonPowIntegStart_pressed(channel) )
        self.buttonPowIntegStart.grid(row=2,column=2,columnspan=1,padx=5)

        return frame

    def setupPanelSaveData(self):
        """

        """
        frame = tk.Frame(self, padx=10, pady=10,bd=1, relief="groove")
        frame.grid(padx=5,row=0,column=7,rowspan=4,sticky="nesw")

        lblSaveDataAutoSaveDt = tk.Label(frame, text="auto-save period (s)", justify="left")
        lblSaveDataAutoSaveDt.grid(row=1,column=0,sticky="e")

        self.entrySaveDataAutosaveDt  = tk.Entry(frame, textvariable=self.saveDataAutosaveDt, relief="sunken", width=6, justify="right")
        self.entrySaveDataAutosaveDt.grid(row=1,column=1, sticky="nesw")

        lblSaveDataFileName = tk.Label(frame, text="file name", justify="left")
        lblSaveDataFileName.grid(row=0,column=0, sticky="e")

        self.entryFileName  = tk.Entry(frame, textvariable=self.saveDataFileName, relief="sunken", width=6, justify="right")
        self.entryFileName.grid(row=0,column=1, sticky="nesw")

        tk.Checkbutton(frame, text="auto-save", variable=self.saveDataAutosave, onvalue=1, offvalue=0).grid(row=0,column=3,sticky="w",columnspan=1)
        tk.Checkbutton(frame, text="save log", variable=self.saveDataSaveLog, onvalue=1, offvalue=0).grid(row=1,column=3,sticky="w",columnspan=1)

        return frame

    ### GUI menu functions

    def saveData(self,startSecondsAgo=None):
        """Method is called from menu toolbar->save and the readings from the power-supply are written to a text file."""

        # suggest a file name
        #   make a time stamp for files
        ts = datetime.datetime.now()
        ts = str(ts.year)+str(ts.month).zfill(2)+str(ts.day).zfill(2)+"-"+str(ts.hour).zfill(2)+str(ts.minute).zfill(2)+str(ts.second).zfill(2)

        initialFileName = "power-supply_"+ts+".dat"

        # open file dialogue
        path2file = filedialog.asksaveasfilename(master=None,title="Save session data as",initialfile=initialFileName,filetypes=[("Data files","*.dat")],defaultextension="*.dat")
        if len(path2file)<3: # asksaveasfilename return `None` if dialog closed with "cancel".
            return None
        # write log to file
        try:
            with open(path2file,"w") as datafile:
                # write header
                datafile.write("time-stamp\truntime")
                for i in range(0,self.powerSupply.numberOfChannels):
                    datafile.write(f"\tOutput({i})\tVset({i})\tIset({i})\tVmeas({i})\tImeas({i})")
                datafile.write("\n")

                # write data
                for entry in self.powerSupplyDataLog:
                    if startSecondsAgo is None or entry[1] < startSecondsAgo: # only write recent data
                        # time stamp
                        datafile.write(str(entry[0])+"\t"+str(entry[1]))
                        for chDta in entry[2:]:
                            datafile.write("\t")
                            datafile.write(f"{int(chDta[0])}\t{chDta[1]}\t{chDta[2]}\t{chDta[3]}\t{chDta[4]}")
                        datafile.write("\n")

            log.debug("data-log written, path: "+path2file)
        except:
            tk.messagebox.showwarning(title="Cannot write data to file", message="Cannot write session data to file. Maybe due to unsufficient permissions?")

        return


    def menuSettingsChannelLimits(self, channel):
        """Function that is called from menu "Settings" and allows for setting Vmax, Imax etc. for the particular channel."""

        # make a frame
        frame = tk.Tk()
        ttl = "power supply channel "+str(channel)
        frame.title(ttl)

        # Vmin
        lblVmin = tk.Label(frame, text="Vmin (V)", justify="left")
        lblVmin.grid(row=0, column=0, sticky="nsew", padx=2, pady=2)
        entryVmin = tk.Entry(frame, relief="sunken", width=8, justify="right")
        entryVmin.insert(tk.INSERT,str(self.powerSupply.Vmin[channel])) # initialise with current value
        entryVmin.grid(row=0, column=1, sticky="nsew", padx=2, pady=2)

        # Vmax
        lblVmax = tk.Label(frame, text="Vmax (V)", justify="left")
        lblVmax.grid(row=1, column=0, sticky="nsew", padx=2, pady=2)
        entryVmax = tk.Entry(frame, relief="sunken", width=8, justify="right")
        entryVmax.insert(tk.INSERT,str(self.powerSupply.Vmax[channel])) # initialise with current value
        entryVmax.grid(row=1, column=1, sticky="nsew", padx=2, pady=2)

        # Imin
        lblImin = tk.Label(frame, text="Imin (V)", justify="left")
        lblImin.grid(row=2, column=0, sticky="nsew", padx=2, pady=2)
        entryImin = tk.Entry(frame, relief="sunken", width=8, justify="right")
        entryImin.insert(tk.INSERT,str(self.powerSupply.Imin[channel])) # initialise with current value
        entryImin.grid(row=2, column=1, sticky="nsew", padx=2, pady=2)

        # Imax
        lblImax = tk.Label(frame, text="Imax (V)", justify="left")
        lblImax.grid(row=3, column=0, sticky="nsew", padx=2, pady=2)
        entryImax = tk.Entry(frame, relief="sunken", width=8, justify="right")
        entryImax.insert(tk.INSERT,str(self.powerSupply.Imax[channel])) # initialise with current value
        entryImax.grid(row=3, column=1, sticky="nsew", padx=2, pady=2)


        ok_button = tk.Button(frame, text="OK", command= lambda: { # lamba function to read values from text entries
            self.powerSupply.Vmin.set(float(entryVmin.get()), index=channel),
            self.powerSupply.Vmax.set(float(entryVmax.get()), index=channel),
            self.powerSupply.Imin.set(float(entryImin.get()), index=channel),
            self.powerSupply.Imax.set(float(entryImax.get()), index=channel),
            log.info(f"user changed power supply voltage and/or current limits for channel {channel}"),
            frame.destroy()})
        ok_button.grid(row=4, column=2, sticky="nsew", padx=2, pady=2)

        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        frame.minsize(300, 50)

        # add window to list of open windows and make sure it will be deleted of user closes it
        frame.protocol("WM_DELETE_WINDOW", lambda w=frame: self.remove_window(w))
        self.windows.append(frame)

    def menuAbout(self):
        """Method showing information about the GUI and PowerSupply/Plus."""
        # make a frame to display the text
        frame = tk.Tk()
        frame.title("About PowerSupply and PowerSupplyGUI")

        # make string with the "about" text
        aboutString = self.makeAboutString()

        # display the about string
        textwin = scrolledtext.ScrolledText(frame, wrap=tk.WORD, width=100, height=20)
        textwin.insert(tk.INSERT, aboutString)
        textwin.config(state=tk.DISABLED) # read only
        textwin.grid(row=0, column=0, sticky="nsew", padx=2, pady=2, columnspan=4)
        save_button = tk.Button(frame, text="Save to File", command=self.menuAboutSaveString)
        save_button.grid(row=1, column=1, sticky="nsew", padx=2, pady=2)
        ok_button = tk.Button(frame, text="OK", command=frame.destroy)
        ok_button.grid(row=1, column=2, sticky="nsew", padx=2, pady=2)

        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        frame.minsize(400, 200)

        # add window to list of open windows and make sure it will be deleted of user closes it
        frame.protocol("WM_DELETE_WINDOW", lambda w=frame: self.remove_window(w))
        self.windows.append(frame)


        return

    def makeAboutString(self):
        """Make the string that is displayed in GUI menu entry "About"."""
        aboutString =  "Module PowerSupply\n"
        aboutString += "version ........... "+version+"\n"
        aboutString += "author ............ "+author+"\n"
        aboutString += "requires Python ... "+pythonVersion+"\n"
        aboutString += "file .............. PowerSupply.py\n"
        aboutString += "-------------------------------------------\n"

        # display classes in module PowerSupply
        aboutString += "classes in module:\n"
        powerSupplyModule = importlib.import_module("PowerBison.PowerSupply")
        classes = [
                    name for name, cl in inspect.getmembers(powerSupplyModule, inspect.isclass)
                    if cl.__module__ == "PowerBison.PowerSupply"
                ]
        for cl in classes:
            aboutString += cl + "\n"

        # check which wrapper class is used to handle the particular power supply
        aboutString += "===========================================\n"
        aboutString += "Instrument:\n"
        aboutString += "power supply name . "+self.powerSupply.name+"\n"
        aboutString += "connected via ..... "+self.powerSupply.port+"\n"
        aboutString += "wrapper module .... "+self.powerSupply.__class__.__module__+"\n"
        aboutString += "wrapper class ..... "+self.powerSupply.__class__.__name__+"\n"

        if self.powerSupply.__class__.__module__ != "PowerSupply": # we are actually using a wrapper
            try:
                powerSupplyWrapperModule = importlib.import_module(self.powerSupply.__class__.__module__)
                if hasattr(powerSupplyWrapperModule, "version"):       aboutString += "version ........... "+ powerSupplyWrapperModule.version+"\n"
                if hasattr(powerSupplyWrapperModule, "author"):        aboutString += "author ............ "+ powerSupplyWrapperModule.author+"\n"
                if hasattr(powerSupplyWrapperModule, "pythonVersion"): aboutString += "requires Python ... "+ powerSupplyWrapperModule.pythonVersion+"\n"
                aboutString += "-------------------------------------------\n"
                aboutString += "classes in module:\n"
                classes = [
                    name for name, obj in inspect.getmembers(powerSupplyWrapperModule)
                    if inspect.isclass(obj) and obj.__module__ == self.powerSupply.__class__.__module__
                ]
                for cl in classes:
                    aboutString += cl + "\n"
            except:
                aboutString += "no further information available"

        # add information on environment
        aboutString += "===========================================\n"
        aboutString += "operating system .. "+platform.system()+"\n"
        aboutString += "OS version ........."+platform.version()+"\n"
        aboutString += "OS release ........ "+platform.release()+"\n"
        aboutString += "PC name ........... "+socket.gethostname()+"\n"
        aboutString += "user .............. "+getpass.getuser()+"\n"
        aboutString += "total RAM (GB) .... "+str(round(psutil.virtual_memory().total / (1024 ** 3), 2))+"\n"
        aboutString += "free RAM (GB) ..... "+str(round(psutil.virtual_memory().available / (1024 ** 3), 2))+"\n"
        aboutString += "free HDD space (GB) "+str(round(psutil.disk_usage('/').free / (1024 ** 3), 2))+"\n"
        aboutString += "Python ............ "+str(sys.version_info[0])+"."+str(sys.version_info[1])+"\n"

        return aboutString

    def menuAboutSaveString(self,fileName=None):
        """Save the information on the power supply to file."""
        aboutString = self.makeAboutString()

        if fileName is None:
            fileName = filedialog.asksaveasfilename(filetypes = (("Text files", "*.txt"),("All files", "*.*") ))

        # write file
        try:
            with open(fileName, "w") as f:
                f.write(aboutString)
        except:
            tk.messagebox.showerror("Error", "Cannot write to file. Maybe due to unsufficient permissions?")
        return


    def menuLoggingSaveSessionLog(self):
        """Menu entry function - Logging -> Save Session"""
        # make a time stamp
        ts = datetime.datetime.now()
        # suggest a log file name: PowerSupply.name_Time-Stamp.log
        initial = self.powerSupply.name+"_"+str(ts.year)+str(ts.month).zfill(2)+str(ts.day).zfill(2)+"-"+str(ts.hour).zfill(2)+str(ts.minute).zfill(2)+str(ts.second).zfill(2)+".log"

        # open save-as dialogue and get path and file name
        path2file = filedialog.asksaveasfilename(master=None,title="Save log-file as",initialfile=initial,filetypes=[("Log Files","*.log")],defaultextension="*.log")
        if len(path2file)<3: # asksaveasfilename return `None` if dialog closed with "cancel".
            return None
        # write log to file
        self.powerSupply.sessionLogWrite2File(path2file)
        log.debug("log-file written, path: "+path2file)
        return

    def menuLoggingShowSessionLog(self):
        """Menu entry function - Logging -> Show Session Log, will open a scrolled text window."""
        # make a text string from session log
        logstr = str("")

        for entry in self.powerSupply.sessionLog:
            for entryField in entry:
                logstr += str(entryField)+"\t"
            logstr+="\n"

        # make a frame to display the text
        frame = tk.Tk()

        # add frame to list of windows
        self.windows.append(frame)

        # make frame title with time stamp
        ts = datetime.datetime.now() # make a time stamp
        frame.title("Session Log "+"("+str(ts.year)+str(ts.month).zfill(2)+str(ts.day).zfill(2)+"-"+str(ts.hour).zfill(2)+str(ts.minute).zfill(2)+str(ts.second).zfill(2)+")")

        textwin = scrolledtext.ScrolledText(frame, wrap=tk.WORD, width=100, height=20)
        textwin.insert(tk.INSERT, logstr)
        textwin.config(state=tk.DISABLED) # read only
        textwin.grid(row=0, column=0, sticky="nsew", padx=2, pady=2,columnspan=3)

        save_button = tk.Button(frame, text="Save to File", command=self.menuLoggingSaveSessionLog)
        save_button.grid(row=1, column=1, sticky="nsew", padx=2, pady=2)

        ok_button = tk.Button(frame, text="OK", command=frame.destroy)
        ok_button.grid(row=1, column=2, sticky="nsew", padx=2, pady=2)#.pack(pady=5)

        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        frame.minsize(400, 200)
        return

    def menuLoggingPlotSessionLog(self):
        """Menu entry function - Logging -> Plot Session Log, will plot the output data in a matplotlib plot window."""

        # convert logged data to numpy arrays
        # initialise variables
        t     = np.zeros(shape=(len(self.powerSupplyDataLog),1)) # time
        chDtaLst = [None]*self.powerSupply.numberOfChannels
        for i in range(0,self.powerSupply.numberOfChannels):
            chDtaLst[i] = np.zeros(shape=(len(self.powerSupplyDataLog),5)) # 0=on/off | 1=V_set | 2=I_set | 3=V_is | 4=I_is
        
        # copy data to numpy arrays
        i=0 # entry index (that is time points)
        for entry in self.powerSupplyDataLog:
            # time (seconds ago)
            t[i] = entry[1] # write time
            # data
            for c in range(0,self.powerSupply.numberOfChannels):
                chDtaLst[c][i][0] = int(entry[c+2][0]) # on/off
                chDtaLst[c][i][1] = entry[c+2][1] # V_set
                chDtaLst[c][i][2] = entry[c+2][2] # I_set
                chDtaLst[c][i][3] = entry[c+2][3] # V_is
                chDtaLst[c][i][4] = entry[c+2][4] # I_is
            i+=1
      
        # set up a plot with N=number_of_channels panels
        fig, *axes = plt.subplots(nrows=self.powerSupply.numberOfChannels, layout='constrained')
        for c in range(0,self.powerSupply.numberOfChannels):
            ax = axes[c]
            ax.set_xlabel('time (s)')
            ax.set_ylabel('voltage (V)',color='#D00000')
            ax.plot(t,chDtaLst[c][0:,3],color='#D00000') # V_is
            ax2 = ax.twinx()
            ax2.set_ylabel('current (A)',color='#0000C0')            
            ax2.plot(t,chDtaLst[c][0:,4],color='#0000C0') # I_is
        #fig = plt.figure(num='Power Supply Session Log');
        plt.show()



    def menuLoggingClearSessionLog(self):
        """Menu entry function - Logging -> Clear Session Log"""
        # confirm that user really wants to clear the session log
        # open a tkinter message box
        if messagebox.askyesno("Clear session log?","Do you really want to clear the session log? This action cannot be undone."):
            self.powerSupply.sessionLogClear() # clear session log
            self.powerSupplyDataLog  = [] # clear all data
        return

    ### GUI methods

    # Basic panel widgets

    def entrySetpointVoltage_returnPressed(self, channel):
        """
        Method is executed when user enters a voltage and hits return/enter.
        """
        # get value from entry
        Vset = float(self.entrySetpointVoltage[channel].get())
        # check if value is within the given limits
        if Vset<self.powerSupply.Vmin[channel]:
            self.powerSupply.Vset.set(new_data=self.powerSupply.Vmin[channel],index=channel)
        if Vset>self.powerSupply.Vmax[channel]:
            self.powerSupply.Vset.set(new_data=self.powerSupply.Vmax[channel],index=channel)
        # send command to power supply
        self.powerSupply.setVoltage(V=Vset, channel=channel)
        # update entry
        self.entrySetpointVoltage[channel].delete(0,tk.END)
        self.entrySetpointVoltage[channel].insert(0,str(self.powerSupply.Vset[channel]))
        return

    def entrySetpointCurrent_returnPressed(self, channel):
        """
        Method is executed when user enters a set-point for the current and hits return/enter.
        """
        # get value from entry
        Iset = float(self.entrySetpointCurrent[channel].get())
        # check if value is within the given limits
        if Iset<self.powerSupply.Imin[channel]:
            self.powerSupply.Iset.set(new_data=self.powerSupply.Imin[channel],index=channel)
        if Iset>self.powerSupply.Imax[channel]:
            self.powerSupply.Iset.set(new_data=self.powerSupply.Imax[channel],index=channel)
        # send command to power supply
        self.powerSupply.setCurrent(I=Iset, channel=channel)
        # update entry
        self.entrySetpointCurrent[channel].delete(0,tk.END)
        self.entrySetpointCurrent[channel].insert(0,str(self.powerSupply.Iset[channel]))
        return

    def buttonSetpoint_pressed(self,event):
        """
        Method is executed when user presses the "Set" button.
        """
        self.entrySetpointVoltage_returnPressed(event)
        time.sleep(0.25)
        self.entrySetpointCurrent_returnPressed(event)
        return

    def readValues(self, interval=0.5):
        """
        Ask power supply frequently about the actual voltage and current values.
        Method should be called by a separate thread.
        interval is provided in seconds.
        """
        while self.readVoltageAndCurrentValues and not self.stopThreads.is_set():
            for ch in range(0,self.powerSupply.numberOfChannels):
                # update GUI labels
                V=self.powerSupply.getVoltage(channel=ch) # get voltage from power supply
                try: self.Vreading[ch].set(round(V,3))
                except: self.Vreading[ch].set(float('nan'))

                I=self.powerSupply.getCurrent(channel=ch) # get current from power supply
                try: self.Ireading[ch].set(round(I,3))
                except: self.Ireading[ch].set(float('nan'))
                # update button texts (timer, voltage ramp, integrators...)
                if not self.powerSupply.TimerRunning[ch]: self.buttonTimerRunText[ch].set("Run")
                if not self.powerSupply.VRampRunning[ch]: self.buttonVRampRunText[ch].set("Run")
                if not self.powerSupply.IIntegRunning[ch]: self.buttonIIntegStartText[ch].set("Run")
                if not self.powerSupply.PowIntegRunning[ch]: self.buttonPowIntegStartText[ch].set("Run")
                # TODO write values to data / log files
            time.sleep(interval)

    def readValuesThreaded(self, interval=0.5):
        """
        Start a thread that is permanently reading voltage and current from the power supply.
        Thread can be stopped by setting self.readVoltageAndCurrentValues = False.
        """
        readValuesThread = threading.Thread(target=self.readValues,
                                  args=[interval])
        readValuesThread.start()
        log.debug("readValues thread started")
        return readValuesThread

    def turnOutputOnOff(self, channel=0):
        """
        Send a turn on/off output command to power supply.
        """
        self.powerSupply.setOutputOn(onOff=not self.powerSupply.OutputOn[channel], channel=channel)

    # timer
    def buttonTimerRun_pressed(self,channel):
        """Start a timer with the given countdown time."""

        # check if a timer is already running for this channel
        if self.powerSupply.TimerRunning[channel]:
            self.powerSupply.TimerRunning.set(False,index=channel)
            self.buttonTimerRunText[channel].set("Run")
            return

        # get value from entry
        try:
            countdownTime = float(self.entryTimerCountdown[channel].get())
        except:
            tk.messagebox.Message("Please enter a float number to run the timer!")
            return
        # get unit (seconds, minutes, hours ...) and multiply countdownTime with the appropriate factor
        match self.comboboxTimerUnits[channel].get():
            case "minutes":
                countdownTime *= 60
            case "hours":
                countdownTime *= 3600
            case "days":
                countdownTime *= 86400
        # calculate end time
        timerEnds = datetime.datetime.now()+datetime.timedelta(seconds=countdownTime)
        # convert to string
        timerEnds = str(timerEnds.year)+str(timerEnds.month).zfill(2)+str(timerEnds.day).zfill(2)+"-"+str(timerEnds.hour).zfill(2)+str(timerEnds.minute).zfill(2)+str(timerEnds.second).zfill(2)

        # display in label in GUI
        self.lblCountDownFinish[channel].config(text=timerEnds)

        # set timer countdown time in PowerSupplyPlus
        self.powerSupply.TimerCountdownTime.set(countdownTime, channel)

        # output will be turned on so set checkbox
        self.checkButtonOutputOnOffState[channel].set(True)

        # run timer
        self.powerSupply.timerThreaded(channel, [lambda: self.checkButtonOutputOnOffState[channel].set(False)])

        # set button text
        self.buttonTimerRunText[channel].set("Stop")

        return

    # voltage ramp

    def entryVRampVstart_returnPressed(self, channel):
        """
        Get the new start value for voltage ramp from entry and submit it to power supply.
        """
        # get value from entry
        try:
            Vstart = float(self.entryVRampVstart[channel].get())
        except:
            tk.messagebox.Message("Please enter a float number to run a voltage-ramp!")
            return
        # check if value is within the given limits
        if Vstart<self.powerSupply.Vmin[channel]:
            Vstart=self.powerSupply.Vmin[channel]
        if Vstart>self.powerSupply.Vmax[channel]:
            Vstart=self.powerSupply.Vmax[channel]
        # send command to power supply
        self.powerSupply.VRampVstart.set(Vstart, channel)
        # update entry
        self.entryVRampVstart[channel].delete(0,tk.END)
        self.entryVRampVstart[channel].insert(0,str(self.powerSupply.VRampVstart[channel]))
        return

    def entryVRampVend_returnPressed(self, channel):
        """
        Get the new end value for voltage ramp from entry and submit it to power supply.
        """
        # get value from entry
        Vend = float(self.entryVRampVend[channel].get())
        # check if value is within the given limits
        if Vend<self.powerSupply.Vmin[channel]:
            Vend=self.powerSupply.Vmin[channel]
        if Vend>self.powerSupply.Vmax[channel]:
            Vend=self.powerSupply.Vmax[channel]
        # send command to power supply
        self.powerSupply.VRampVend.set(Vend, channel)
        # update entry
        self.entryVRampVend[channel].delete(0,tk.END)
        self.entryVRampVend[channel].insert(0,str(self.powerSupply.VRampVend[channel]))
        return

    def entryVRampSteps_returnPressed(self, channel):
        """
        Get number of steps for voltage ramp from entry and submit it to power supply.
        """
        # get value from entry
        Vsteps = int(self.entryVRampSteps[channel].get())
        # check if value makes sense
        if Vsteps<=0:
            Vsteps=1
        # send command to power supply
        self.powerSupply.VRampSteps.set(Vsteps, channel)
        # update entry
        self.entryVRampSteps[channel].delete(0,tk.END)
        self.entryVRampSteps[channel].insert(0,str(self.powerSupply.VRampSteps[channel]))
        return

    def entryVRampDt_returnPressed(self, channel):
        """
        Get interval for voltage ramp from entry and submit it to power supply.
        """
        # get value from entry
        dt = float(self.entryVRampDt[channel].get())
        # check if value makes sense
        if dt<=0.01:
            dt=0.01
        # send command to power supply
        self.powerSupply.VRampDt.set(dt, channel)
        # update entry
        self.entryVRampDt[channel].delete(0,tk.END)
        self.entryVRampDt[channel].insert(0,str(self.powerSupply.VRampDt[channel]))
        return

    def entryVRampCycles_returnPressed(self, channel):
        """
        Get number of cycles for the voltage ramp and submit it to power supply.
        """
        # get value from entry
        cyc = int(self.entryVRampCycles[channel].get())
        # check if value makes sense
        if cyc<=0:
            cyc=1
        # send command to power supply
        self.powerSupply.VRampCycles.set(cyc, channel)
        # update entry
        self.entryVRampCycles[channel].delete(0,tk.END)
        self.entryVRampCycles[channel].insert(0,str(self.powerSupply.VRampCycles[channel]))
        return

    def entryVRampInterrampDelay_returnPressed(self, channel):
        """
        Get the delay (in seconds) between ramping up and then down again for the voltage ramp and submit it to power supply.
        """
        # get value from entry
        delay = float(self.entryVRampInterrampDelay[channel].get())
        # check if value makes sense
        if delay<=0.01:
            delay=0.01
        # send command to power supply
        self.powerSupply.VRampInterrampDelay.set(delay, channel)
        # update entry
        self.entryVRampInterrampDelay[channel].delete(0,tk.END)
        self.entryVRampInterrampDelay[channel].insert(0,str(self.powerSupply.VRampInterrampDelay[channel]))
        return

    def entryVRampIntercycleDelay_returnPressed(self, channel):
        """
        Get the delay (in seconds) between cycles of a voltage ramp and submit it to power supply.
        """
        # get value from entry
        delay = float(self.entryVRampIntercycleDelay[channel].get())
        # check if value makes sense
        if delay<=0.01:
            delay=0.01
        # send command to power supply
        self.powerSupply.VRampIntercycleDelay.set(delay, channel)
        # update entry
        self.entryVRampIntercycleDelay[channel].delete(0,tk.END)
        self.entryVRampIntercycleDelay[channel].insert(0,str(self.powerSupply.VRampIntercycleDelay[channel]))
        return

    def checkButtonVRampFullRamp_ticked(self,channel):
        """
        User can indicate whether the voltage should be ramped up and down again or not in a voltage ramp.
        State of check submit it to power supply.
        """
        # get state from checkbutton
        chkstate = self.checkButtonVRampFullRamp[channel].state()
        state = True
        if 'selected' in chkstate:
            state= False
        self.powerSupply._VRampUpAndDown.set(state,channel)

    def buttonVRampRun_pressed(self, channel):
        """
        Start ramping voltage in steps.
        """
        # if a voltage ramp is already running for this channel stop the thread
        if self.powerSupply.VRampRunning[channel]:
            self.powerSupply.VRampRunning.set(False,index=channel)
            self.buttonVRampRunText[channel].set("Run")
            return
        # read values from all entries
        self.entryVRampCycles_returnPressed(channel)
        self.entryVRampDt_returnPressed(channel)
        self.entryVRampIntercycleDelay_returnPressed(channel)
        self.entryVRampInterrampDelay_returnPressed(channel)
        self.entryVRampSteps_returnPressed(channel)
        self.entryVRampVstart_returnPressed(channel)
        self.entryVRampVend_returnPressed(channel)
        # start voltage ramp
        self.buttonVRampRunText[channel].set("Stop")
        self.powerSupply.voltageRampThreaded(channel=channel)

    # current integration

    def buttonIIntegStart_pressed(self,channel):
        """
        Start current integration.
        """
        # if a current integration is already running then stop the thread
        if self.powerSupply.IIntegRunning[channel]:
            self.powerSupply.IIntegRunning.set(False,index=channel)
            self.buttonIIntegStartText[channel].set("Run")
            return
        # if no current integration is running start it
        self.buttonIIntegStartText[channel].set("Stop")
        self.powerSupply.integrateCurrentThreaded(channel)
        # turn on the charge updater
        self.IIntegChargeReaderThreaded(channel)


    def checkButtonIIntegOutputOff_ticked(self,channel):
        """
        User can indicate whether power supply output shall be turned off when maximaum charge is reached.
        """
        # get previous state from checkbutton
        chkstate = self.checkButtonIIntegOutputOff[channel].state()
        state = False
        if 'selected' in chkstate: # this means that user has unselected this!
            self.entryIIntegMaxCharge[channel].config(state="disabled")
        else:
            state= True
            if not self.powerSupply.IIntegRunning[channel]: # enable checkbox, if no integration is running
                self.entryIIntegMaxCharge[channel].config(state="normal")
        return state

    def IIntegChargeReader(self,channel):
        """
        Thread that is reading the charge from current integration.
        It updates the text label in the GUI and turns off the power supply output once the maximum charge is reached.
        """
        # get user defined maximum charge
        maxCharge = float(self.entryIIntegMaxCharge[channel].get())
        # set maximum charge entry inactive
        self.entryIIntegMaxCharge[channel].config(state="disabled")
        # check if user wants to turn off power supply output if maximum energy has been delivered
        outputOff = False
        if 'selected' in self.checkButtonIIntegOutputOff[channel].state(): outputOff = True

        # as long as current is being integrated read values
        while self.powerSupply.IIntegRunning[channel]:
            # set charge in label
            self.IIntegCharge[channel].set(str(round(self.powerSupply.IIntegCharge[channel],3)))
            if self.powerSupply.IIntegCharge[channel] >= maxCharge  and outputOff:
                #  turn off output (if on, which should be the case) and stop loop
                if self.powerSupply.OutputOn[channel] and outputOff:
                    self.checkButtonOutputOnOff[channel].invoke() # untick checkbutton output in panel basic
                    self.turnOutputOnOff(channel) # send output off command to power supply
                # obviously the maximum charge has been reached -> send stop signal
                self.powerSupply.IIntegRunning.set(False,index=channel)
                break

            time.sleep(self.powerSupply.IIntegDt[channel])

        #  -> reset run/stop button
        self.buttonIIntegStartText[channel].set("Run")

        # stop timer, voltage ramp and power integration (if running) if output is switched off
        if outputOff:
            self.powerSupply.TimerRunning.set(False,channel)
            self.powerSupply.VRampRunning.set(False,channel)
            self.powerSupply.PowIntegRunning.set(False,channel)
            # set maximum charge entry active again
            self.entryIIntegMaxCharge[channel].config(state="normal")

    def IIntegChargeReaderThreaded(self, channel):
        """
        Start a thread that is permanently reading integrated current / charge from power supply.
        Thread can be stopped by setting self.powerSupply.IIntegRunning[channel] to False.
        """
        updateIIntegChargeLabelThread = threading.Thread(target=self.IIntegChargeReader,
                                  args=[channel])
        updateIIntegChargeLabelThread.start()
        log.debug("updateIIntegChargeLabelThread thread started")
        return updateIIntegChargeLabelThread

    # power integration

    def buttonPowIntegStart_pressed(self,channel):
        """
        Start power integration.
        """
        # if a power integration is already running then stop the thread
        if self.powerSupply.PowIntegRunning[channel]:
            self.powerSupply.PowIntegRunning.set(False,index=channel)
            self.buttonPowIntegStartText[channel].set("Run")
            return
        # if no current integration is running start it
        self.buttonPowIntegStartText[channel].set("Stop")
        self.powerSupply.integratePowerThreaded(channel)
        # turn on the energy updater
        self.PowIntegEnergyReaderThreaded(channel)

    def checkButtonPowIntegOutputOff_ticked(self,channel):
        """
        User can indicate whether power supply output shall be turned off when maximum energy is reached.
        """
        # get previous state from checkbutton
        chkstate = self.checkButtonPowIntegOutputOff[channel].state()
        state = False
        if 'selected' in chkstate: # this means that user has unselected this!
            self.entryPowIntegMaxEnergy[channel].config(state="disabled")
        else:
            state= True
            if not self.powerSupply.PowIntegRunning[channel]: # enable checkbox, if no integration is running
                self.entryPowIntegMaxEnergy[channel].config(state="normal")
        return state

    def PowIntegEnergyReader(self,channel):
        """
        Thread that is reading the energy from current integration.
        It updates the text label in the GUI and turns off the power supply output once the maximum energy is reached.
        """
        # get user defined maximum charge
        maxEnergy = float(self.entryPowIntegMaxEnergy[channel].get())
        # set maximum energy entry inactive
        self.entryPowIntegMaxEnergy[channel].config(state="disabled")
        # check if user wants to turn off power supply output if maximum energy has been delivered
        outputOff = False
        if 'selected' in self.checkButtonPowIntegOutputOff[channel].state(): outputOff = True

        # as long as power is being integrated read values
        while self.powerSupply.PowIntegRunning[channel]:
            # set energy in label
            self.PowIntegEnergy[channel].set(str(round(self.powerSupply.PowIntegEnergy[channel],3)))

            if self.powerSupply.PowIntegEnergy[channel] >= maxEnergy and outputOff:
                #  turn off output (if on, which should be the ) and stop loop
                if self.powerSupply.OutputOn[channel]:
                    self.checkButtonOutputOnOff[channel].invoke() # untick checkbutton output in panel basic
                    self.turnOutputOnOff(channel) # send output off command to power supply
                break
            time.sleep(self.powerSupply.PowIntegDt[channel])
        # obviously the maximum energy has been reached
        self.powerSupply.PowIntegRunning.set(False,index=channel)
        #  -> reset run/stop button
        self.buttonPowIntegStartText[channel].set("Run")

        # if output off is checked -> stop timer, voltage ramp and current integration (if running)
        if outputOff:
            self.powerSupply.TimerRunning.set(False,channel)
            self.powerSupply.VRampRunning.set(False,channel)
            self.powerSupply.IIntegRunning.set(False,channel)
            # set maximum charge entry active again
            self.entryIIntegMaxCharge[channel].config(state="normal")

    def PowIntegEnergyReaderThreaded(self, channel):
        """
        Start a thread that is permanently reading integrated power / energy from power supply.
        Thread can be stopped by setting self.powerSupply.PowIntegRunning[channel] to False.
        """
        updatePowIntegEnergyLabelThread = threading.Thread(target=self.PowIntegEnergyReader,
                                  args=[channel])
        updatePowIntegEnergyLabelThread.start()
        log.debug("updatePowIntegEnergyLabelThread thread started")
        return updatePowIntegEnergyLabelThread

    ### write a log of the power-supply
    def powerSupplyDataLogger(self,varName,idx=0,typeOfOperation=None):
        """

        """
        if self.powerSupplyDataLoggerOn:
            # make a time stamp
            tnow = datetime.datetime.now()
            tm = str(tnow.year)+str(tnow.month).zfill(2)+str(tnow.day).zfill(2)+"-"+str(tnow.hour).zfill(2)+str(tnow.minute).zfill(2)+str(tnow.second).zfill(2)

            # write two log entries - old state and new state
            # for old entry copy last entry in data log and modify the time stamp
            if len(self.powerSupplyDataLog) > 0:
                    logEntryOld = copy.deepcopy(self.powerSupplyDataLog[len(self.powerSupplyDataLog)-1])
                    logEntryOld[0] = tm
                    logEntryOld[1] = (tnow-tstart).total_seconds()
                    self.powerSupplyDataLog.append(logEntryOld)

            # get data and make new log entry
            logEntry = [tm]
            logEntry.append((tnow-tstart).total_seconds())

            for ch in range(0,self.powerSupply.numberOfChannels):
                logEntry.append([
                    self.powerSupply.OutputOn[ch], # output on or off
                    self.powerSupply.Vset[ch], self.powerSupply.Iset[ch], # voltage and current set point
                    self.Vreading[ch].get(), self.Ireading[ch].get() # voltage and current reading
                    ])

            lenLog = len(self.powerSupplyDataLog)
            # write to log only if some value has changed
            if lenLog==0 or self.powerSupplyDataLog[lenLog-1][2:]!=logEntry[2:]:
                self.powerSupplyDataLog.append(logEntry)

    ### dynamically change the window title if self.name changes
    def setWindowTitle(self,varName,idx,typeOfOperation):
        """
        Dynamically change the window title if self.name changes.
        Method must be hooked to self.name.trace('w',setWindowTitle).
        """
        self.master.title(self.name.get())

    ### special methods












