version = "28th April 2026"
author  = "Matthias Schmidt"
pythonVersion = "3.10"

import serial
from serial.tools import list_ports

import PowerBison.PowerSupply
# threading (in order to use mutexes)
import threading
# time for waits during device reads
import time

# import GUI functions for list selection of available serial ports
import tkinter as tk
from PowerBison.GUIfunctions import SelectItemFromList

# get PowerBison logger
import logging
log = PowerBison.PowerSupply.log

###############################################################################################################################
# implementation Joy-It DPM86 power supply
class JoyItDPM86(PowerBison.PowerSupply.PowerSupplyPlus):
    """
    The class overrides the set/get voltage and current methods of PowerSupply.PowerSupplyPlus to control Joy-It DPM86xx power supplies.
    """


    #############################################################################################
    # Constructor
    def __init__(self,name="Joy-It_DPM86", port="/dev/ttyUSB0"):
        """
        Load the settings for this Joy-It DPM8604 power supply from xml file.
        """
        # call constructor of PowerSupply.PowerSupplyPlus
        super().__init__(channels=1) # DPM8604 has just one channel ...

        # connect with Joy-It DPM86 power supply
        log.debug(f"connecting with DPM86 power supply on port {self.port}")
        try:
            self.dpm86PowerSupply = dpm86(port=self.port)
        except serial.serialutil.SerialException: # maybe it's the wrong port
            ports = list(list_ports.comports())
            availablePorts = []
            for i in range(0,len(ports)):
                availablePorts.append(str(ports[i].device)+" "+str(ports[i].manufacturer))
            selected = SelectItemFromList(items=availablePorts, title="select serial port")
            try:
                self.dpm86PowerSupply = dpm86(port=ports[selected].device)
            except:
                raise IOError(f"cannot connect to DPM86 power supply")

        except Exception as e:
            raise IOError(f"cannot connect to DPM86 power supply")

        self.name = name
        self.port = port


        # make it thread-safe
        self.mutex = threading.Lock()

        return

    #############################################################################################
    # implementation of DPM86xx specific functions

    def getVoltage(self,channel=0):
        """
        Read the output voltage from the power supply.
        Since DPM86 only has one channel, channel is ignored.
        """
        with self.mutex: # lock critical section when communicating with DPM86
            try:
                return self.dpm86PowerSupply.voltage()
            except Exception as e:
                log.error(f"error while reading DPM86 voltage, received exception '{e}'")
                return


    def getCurrent(self,channel=0):
        """
        Read the output current from the power supply.
        Since DPM86 only has one channel, channel is ignored.
        """
        with self.mutex: # lock critical section when communicating with DPM86
            try:
                return self.dpm86PowerSupply.current()
            except Exception as e:
                log.error(f"error while reading DPM86 current, received exception '{e}'")
                return

    def setOutputOn(self,onOff=True,channel=0):
        """
        Turn on (on=True) or off (on=False) the output of the power supply.
        Method returns on=True/False.
        Since DPM86 only has one channel, channel is ignored.
        """
        if onOff: # turn on
            with self.mutex: # lock critical section when communicating with DPM86
                try: self.dpm86PowerSupply.output(state=dpm86.p_on)
                except Exception as e:
                    log.error(f"error while trying to turn DPM86 output on, received exception: '{e}'")
                    return
        else: # turn off
            with self.mutex:
                try: self.dpm86PowerSupply.output(state=dpm86.p_off)
                except Exception as e:
                    log.error(f"error while trying to turn DPM86 output off, received exception: '{e}'")
                    return
        log.debug(f"sent outputOn={onOff} to power supply")
        self.OutputOn.set(new_data=onOff,index=channel)
        return onOff

    def setCurrent(self, I,channel=0,logLevel=logging.INFO):
        """
        Change current set-point of the DPM86 power-supply.
        If successful return True otherwise return False.
        Since DPM86 only has one channel, channel is ignored.
        """
        if I<self.Imin[channel] or I>self.Imax[channel]:
            log.info(f"cannot set current to {I} A as it is out of range ({self.Imin[channel]}A, {self.Imax[channel]}A)")
            return False
        else:
            ret = ""
            try:
                with self.mutex: # lock critical section when communicating with DPM86
                    ret = self.dpm86PowerSupply.setting('current', I)
                    log.debug(f"DPM86 reply: {ret}")
            except:
                log.info(ret)
                return False
            log.log(logLevel,f"current set-point of channel {channel} changed to {I}A")
            # update set-point value in GUI
            self.Iset.set(round(I,3),channel)
        return True

    def setVoltage(self, V,channel=0,logLevel=logging.INFO):
        """
        Change current set-point of the DPM86 power-supply.
        If successful return True otherwise return False.
        Since DPM86 only has one channel, channel is ignored.
        """
        if V<self.Vmin[channel] or V>self.Vmax[channel]:
            log.info(f"cannot set voltage to {V} V as it is out of range ({self.Vmin[channel]}V, {self.Vmax[channel]}V)")
            return False
        else:
            ret = ""
            try:
                with self.mutex: # lock critical section when communicating with DPM86
                    ret = self.dpm86PowerSupply.setting('voltage', V)
                    log.debug(f"DPM86 reply: {ret}")
            except:
                log.info(ret)
                return False
            log.log(logLevel, f"voltage set-point of channel {channel} changed to {V} V")
            # update set-point value in GUI
            self.Vset.set(round(V,3),channel)
        return True

class dpm86(serial.Serial):
    """
    source code by Alois Hockenschlohe (2024)
    https://github.com/aloishockenschlohe/dpm86_power_supply/blob/main/dpm86

    Should work with:
    - DPM8605 (see f. e. https://joy-it.net/en/products/JT-DPM8605)

    - DPM8624 (see f. e. https://joy-it.net/en/products/JT-DPM8624)

    - DPM8650 (see f. e. https://joy-it.net/en/products/JT-DPM8650)

    Please note:

    - The power supply has to be set to "simple protocol" (this is the default configuration). Check the manual.

    - Check the variable 'tty' and choose the correct ttyUSB-device.

    - Check the variable 'addr' and choose the correct ID of your power supply ('01' by default).

    Unless you changed the setup of your power supply this should match. If in doubt: Check the manual and your power supply.
    - Be sure that there is no potential difference between the power supply and the controlling device (correctly spoken:
    between the power supply and the USB-RS485 adapter). Otherwise the signal transmission is damn error-prone, which becomes
    noticeable e.g. by strange characters in the transmission (or no transmission at all). Connect both to the same ground.
    - WARNING: The Raspberry 4 seems to be buggy. Try to avoid it. Use an older version instead.
    - This script comes along with no warranty at all. You have been warned.
    - Have fun.
    """
    # DPM settings
    _addr="01"			# Adress of the power supply. Default: 01. Check manual of the power suppy for more information.
    _read="r"
    _write="w"

    # supported dpm functions -- see the document "dpm86xx-series-power-supply_simple-communication-protocol.odt/pdf" in this repository
    F_MAX_VOLTAGE="00"		# R/-: maximum output voltage
    F_MAX_CURRENT="01"		# R/-: maximum output current
    F_VOLTAGE_SETTING="10"		# R/W: output voltage target
    F_CURRENT_SETTING="11"		# R/W: output current target
    F_OUTPUT="12"			# R/W: output on/off
    F_VOLTAGE="30"			# R/-: output voltage
    F_CURRENT="31"			# R/-: output current
    F_CONST="32"			# R/W: constant current or constant voltage status
    F_TEMPERATURE="33"		# R/-: temperature

    VOLTAGE_MIN=0			#  0 Volt
    VOLTAGE_MAX=60			# 60 Volt
    CURRENT_MIN=0			#  0 Ampere
    CURRENT_MAX=9			#  9 Ampere --> should be set automatically, depending on the type (maybe next release)

    # parameter for dpm functions (just for a better reading)
    # function "f_output"
    p_off="0"		# parameter "off"
    p_on ="1"		# parameter "on"

    # function "f_const"
    p_voltage="0"		# parameter "voltage"
    p_current="1"		# parameter "current"

    def __init__(self, port=None, baudrate=9600, timeout=None, inter_byte_timeout=None):
        super().__init__(
            port = port,
            baudrate = baudrate,
            parity = serial.PARITY_NONE,
            stopbits = serial.STOPBITS_ONE,
            bytesize = serial.EIGHTBITS,
            timeout = timeout,
            inter_byte_timeout = inter_byte_timeout
        )
        # pyserial timeout = 2s
        self.timeout = 2.0

        log.debug(f"an instance of dpm86 has been created, device address: {dpm86._addr}, port: {port}, baudrate: {baudrate}")

    # dpm86: lowlevel - read a value
    def vread(self, opcode):

        opcode = str(opcode)

        # sending command
        self.cmd = ":" + dpm86._addr + dpm86._read + opcode + "=0" + ",,\n"
        cmdPrnt = "".join(self.cmd.splitlines())
        dpm86addrPrnt = "".join(dpm86._addr)
        log.debug(f"sending read-request {cmdPrnt} to DPM86 (addr: {dpm86addrPrnt})")
        self.bcmd = self.cmd.encode()
        written = self.write(self.bcmd)
        if written < len(self.bcmd):
            log.warning(f"writing {self.cmd} to DPM86 (addr: {dpm86addrPrnt}) failed: only {written} bytes written")
            raise IOError(f"Writing '{self.cmd}' to DPM86 (addr: {dpm86addrPrnt}) failed: only {written} bytes written.")

        # reading response
        bresponse = self.readline()

        if len(bresponse) == 0: # nothing read -> timeout
            log.warning(f"reading response from DPM86 (addr: {dpm86addrPrnt}) failed: timeout")
            raise IOError(f"reading response from DPM86 (addr: {dpm86addrPrnt}) failed: timeout")

        response = bresponse.decode(errors='replace')
        if response == "":
            log.warning(f"communication with DPM86 (addr: {dpm86addrPrnt}) failed - no response read")
            raise IOError(f"communication with DPM86 (addr: {dpm86addrPrnt}) failed - no response read")
        
        respPrnt ="".join(response.splitlines())
        log.debug(f"received {respPrnt} from DPM86 (addr: {dpm86addrPrnt})")

        # return corrected response as word
        response = response[7:-3]
        if response.isdigit(): response = int(response)
        return response

    # dpm86: lowlevel - write a value
    def vwrite(self, opcode, value):

        opcode = str(opcode)
        value = str(value)

        # send command
        self.cmd =":" + dpm86._addr + dpm86._write + opcode + "=" + value + ",,\n"
        cmdPrnt = "".join(self.cmd.splitlines())
        dpm86addrPrnt = "".join(dpm86._addr)
        log.debug(f"writing to DPM86 (addr: {dpm86addrPrnt}): {cmdPrnt}")
        self.bcmd = self.cmd.encode()
        written = self.write(self.bcmd)

        if written < len(self.bcmd):
            log.warning(f"writing {self.cmd} to DPM86 (addr: {dpm86addrPrnt}) failed: only {written} bytes written")
            raise IOError(f"writing '{self.cmd}' to DPM86 (addr: {dpm86addrPrnt}) failed: only {written} bytes written.")

        # read response
        log.debug(f"reading response from DPM86 (addr: {dpm86addrPrnt})")

        bresponse = self.readline()
        if len(bresponse) == 0: # nothing read -> timeout
            log.warning(f"reading response from DPM86 (addr: {dpm86addrPrnt}) failed: timeout")
            raise IOError(f"reading response from DPM86 (addr: {dpm86addrPrnt}) failed: timeout")
        response = bresponse.decode(errors='replace')

        # check and return value
        response = response[:-2]
        respPrnt ="".join(response.splitlines())
        if response == ":" + dpm86._addr + "ok":
            log.debug(f"DPM86 (addr: {dpm86addrPrnt}) responded 'ok'")
            return("ok")
        else:
            log.warning(f"invalid response from DPM86 (addr: {dpm86addrPrnt}): {respPrnt}")
            raise IOError(f"expected 'ok' from DPM86 (addr: {dpm86addrPrnt}) but received {respPrnt}")

    # dpm86: output
    def output(self, state=None):

        if state == None: return(self.vread(self.F_OUTPUT))
        elif state in [self.p_on, self.p_off]: return(self.vwrite(self.F_OUTPUT, state))
        else: return("ERROR: Invalid parameter.")

    # dpm86: const
    def const(self, state=None):

        if state == None: return(self.vread(self.F_CONST))
        elif state in [self.p_voltage, self.p_current]: return(self.vwrite(self.F_CONST, state))
        else: return("ERROR: Invalid parameter.")

    # dpm86: temperature
    def temperature(self):

        return(self.vread(self.F_TEMPERATURE))

    def volt(self, v):
        if type(v) is not int: return("ERROR reading values.")
        return(float(v) / 100)

    def ampere(self, a):
        if type(a) is not int: return("ERROR reading values.")
        return(float(a) / 1000)

    # dpm86: read delivered current
    def current(self):
        return(self.ampere(self.vread(self.F_CURRENT)))

    # dpm86: read delivered voltage
    def voltage(self):
        return(self.volt(self.vread(self.F_VOLTAGE)))

    # dpm86: read delivered power
    def power(self):

        v = self.volt(self.vread(self.F_VOLTAGE))
        c = self.ampere(self.vread(self.F_CURRENT))
        if type(v) is str or type(c) is str: return("ERROR reading values.")

        return(float(v) * float(c))

    # dpm86: read and set current and voltage setting, read the power setting
    def setting(self, name, value=None):

        if name in ['voltage', 'volt', 'v']:
            if value == None: return(self.volt(self.vread(self.F_VOLTAGE_SETTING)))
            if value == "max": return(self.volt(self.vread(self.F_MAX_VOLTAGE)))
            try:
                value = float(value)
            except:
                return("ERROR: Value for voltage is not an integer or a float.")
            if value < self.VOLTAGE_MIN or value > self.VOLTAGE_MAX: return("ERROR: Value for voltage out of range.")
            return(self.vwrite(self.F_VOLTAGE_SETTING, int(value * 100)))

        elif name in ['current', 'c', 'ampere', 'amp', 'a']:
            if value == None: return(self.ampere(self.vread(self.F_CURRENT_SETTING)))
            if value == "max": return(self.ampere(self.vread(self.F_MAX_CURRENT)))
            try:
                value = float(value)
            except:
                return("ERROR: Value for current is not an integer or a float.")
            if value < self.CURRENT_MIN or value > self.CURRENT_MAX: return("ERROR: Value for current is out of range.")
            return(self.vwrite(self.F_CURRENT_SETTING, int(value * 1000)))
        elif name in ['power', 'p', 'watt', 'w']:
            if value == None:
                v = self.volt(self.vread(self.F_VOLTAGE_SETTING))
                c = self.ampere(self.vread(self.F_CURRENT_SETTING))
                if type(v) is str or type(c) is str: return("ERROR reading values.")
                return(float(v) * float(c))
            return("ERROR: Power expects no additional parameter")
        else:
            return("ERROR: Parameter 'name' unknown value.")

# this is the last line :)




