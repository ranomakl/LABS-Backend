version = "2nd April 2026"
author  = "Max Pohl, Matthias Schmidt"
pythonVersion = "3.10"

# communication via serial port
import serial
# pyvisa drivers to achieve easy communication with instrument
# -> if not installed the drivers come with the package in PowerBison/drivers
import pyvisa
# threading (in order to use mutexes)
import threading
# time for short wait in between the voltage and current readings
import time
# for user messages
#from tkinter import messagebox as messbox

import PowerBison.PowerSupply

# get PowerBison logger
import logging
log = PowerBison.PowerSupply.log


###############################################################################################################################
# implementation Keithley 2230_30_1 power supply
class Keithley2230_30_1(PowerBison.PowerSupply.PowerSupplyPlus):
    """
    The class overrides the set/get voltage and current methods of PowerSupply.PowerSupplyPlus to control Keithley 2230_30_1 power supplies.
    """


    #############################################################################################
    # Constructor
    def __init__(self, name="Keithley 2230_30_1", port='USB0::0x05E6::0x2230::9202777::INSTR'): # address is Manish's Keithley
        """
        Load the Keithley 2230_30_1 power supply.
        """
        # call constructor of PowerSupply.PowerSupplyPlus
        super().__init__(channels=3) # Keithley has 3 channels

        # set name and address
        self.name = name
        self.port = port

        # connect with Keithley2230_30_1
        try:
          self.keithley2230_30_1_PS = keithley2230_30_1(self.port)
        except:
          errstr = "cannot connect to Keithley2230_30_1 on "+str(self.port)
          raise IOError(errstr)

        # make it thread-safe
        self.mutex = threading.Lock()

        return

    #############################################################################################
    # implementation of Keithley specific functions

    def getVoltage(self,channel=0):
        """
        Read the output voltage from the power supply.
        """
        with self.mutex: # lock critical section when communicating with DPM86
            return self.keithley2230_30_1_PS.voltage(channel)

    def getCurrent(self,channel=0):
        """
        Read the output current from the power supply.
        """
        with self.mutex: # lock critical section when communicating with DPM86
            return self.keithley2230_30_1_PS.current(channel)

    def setOutputOn(self,onOff=True,channel=0):
        """
        Turn on (on=True) or off (on=False) the output of the power supply.
        Method returns on=True/False.
        """
        if onOff is True:
            with self.mutex: # lock critical section when communicating with DPM86
                ret = self.keithley2230_30_1_PS.output(onOff,channel)
                log.debug(f"Keithley-Answer: {ret}")
        else:
            with self.mutex:
                ret = self.keithley2230_30_1_PS.output(False,channel)
                log.debug(f"Keithley-Answer: {ret}")
        log.info(f"sent outputOn={onOff} to power supply channel {channel}")
        self.OutputOn.set(new_data=onOff,index=channel)
        return onOff

    def setCurrent(self, I,channel=0,logLevel=logging.INFO):
        """
        Change current set-point of the Keithley 2230_30_1 power-supply.
        If successful return True otherwise return False.
        """
        if I<self.Imin[channel] or I>self.Imax[channel]:
            log.info(f"cannot set current to {I} A as it is out of range ({self.Imin[channel]}A, {self.Imax[channel]}A)")
            return False
        else:
            ret = ""
            try:
                with self.mutex: # lock critical section when communicating with Keithley
                    ret = self.keithley2230_30_1_PS.setVoltageAndCurrent(channel,self.Vset[channel], I)
                    log.debug(f"Keithley-Reply-Current: {ret}")
            except:
                log.info(ret)
                return False
            log.log(logLevel,f"current set-point of channel {channel} changed to {I}A")
            # update set-point value in GUI
            self.Iset.set(round(I,3),channel)
        return True

    def setVoltage(self, V,channel=0,logLevel=logging.INFO):
        """
        Change voltage set-point of the Keithley 2230_30_1 power-supply.
        If successful return True otherwise return False.
        """
        if V<self.Vmin[channel] or V>self.Vmax[channel]:
            log.info(f"cannot set voltage to {V} V as it is out of range ({self.Vmin[channel]}V, {self.Vmax[channel]}V)")
            return False
        else:
            ret = ""
            try:
                with self.mutex: # lock critical section when communicating with Keithley
                    ret = self.keithley2230_30_1_PS.setVoltageAndCurrent(channel, V, self.Iset[channel])
                    log.debug(f"Keithley-Reply-Voltage: {ret}")
            except:
                log.info(ret)
                return False
            log.log(logLevel, f"voltage set-point of channel {channel} changed to {V} V")
            # update set-point value in GUI
            self.Vset.set(round(V,3),channel)
        return True

##############################

class keithley2230_30_1():
    def __init__(self, keithley_address):
        super().__init__()
        rm = pyvisa.ResourceManager()
        print(rm.list_resources())
        self.inst = rm.open_resource(keithley_address)
        self.inst.timeout = 5000

    def select_channel(self,channel):
        if channel in range(0,3):
            self.inst.write("INST CH"+str(channel+1))
            return "CH"+str(channel+1)
        else:
            return("ERROR: Invalid parameter.")

    def output(self, state, channel):
        # select channel on which output on/off shall be applied
        self.select_channel(channel)
        if state == None: return(self.inst.query("CHAN:OUTP?"))
        else:
            if isinstance(state,bool):
                # enable output
                self.inst.write(f"OUTP:ENAB {int(state)}")
                if state==True: # turn output on
                    return self.inst.write("CHAN:OUTP ON")
                else: # turn off output
                    return self.inst.write("CHAN:OUTP OFF")
            else:
                return ("ERROR: Invalid parameter.")

    #Keithley 2230_30_1: initates and executes a voltage measurement on specific channel
    def voltage(self,channel):
        # select channel (maybe selecting is not even necessary)
        ch = self.select_channel(channel) # should return string CH1 or CH2 ...
        v=self.inst.query("MEAS:VOLT? "+ch)
        if isinstance(v,(int,float,str)):
            return(float(v))
        else:
            return("ERROR reading voltage values.")

    #Keithley 2230_30_1: initates and executes a current measurement on specific channel
    def current(self,channel):
        # select channel (maybe selecting is not even necessary)
        ch = self.select_channel(channel) # should return string CH1 or CH2 ...
        i=self.inst.query("MEAS:CURR? "+ch)
        if isinstance(i,(int,float,str)):
            return(float(i))
        else:
            return("ERROR reading current values.")

    def setVoltageAndCurrent(self,channel,V,I):
        # select channel (maybe selecting is not even necessary)
        ch = self.select_channel(channel) # should return string CH1 or CH2 ...
        if not isinstance(V,(int,float)) or not isinstance(I,(int,float)):
            errstr = "error setting voltage and current for channel "+str(channel)+" -> float or int required"
            raise(errstr)
        else:
            return (self.inst.write(f"APPL {ch}, {round(float(V),3)}, {round(float(I),3)}"))


